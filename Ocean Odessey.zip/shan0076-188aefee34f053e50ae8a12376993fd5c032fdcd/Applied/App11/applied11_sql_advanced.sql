/*
Database Teaching Team
applied11_sql_advanced.sql

student id: 
student name:
last modified date:

*/
--1
SELECT unitcode,
       unitname,
       to_char(
           ofyear,
           'yyyy'
       ) AS year,
       ofsemester,
       enrolmark,
       CASE upper(enrolgrade)
           WHEN 'N'  THEN
               'Fail'
           WHEN 'P'  THEN
               'pass'
           WHEN 'C'  THEN
               'credit'
           WHEN 'D'  THEN
               'distinction'
           WHEN 'HD' THEN
               'high distinction'
       END AS explained_grade
  FROM uni.unit
NATURAL JOIN uni.enrolment
 WHERE stuid = (
    SELECT stuid
      FROM uni.student
     WHERE upper(stufname) = upper('Claudette')
       AND upper(stulname) = upper('serman')
)
 ORDER BY year,
          ofsemester,
          unitcode;

--2



--3


--4

/* Using outer join */
SELECT U.UNITCODE, U.UNITNAME FROM UNI.UNIT U 
LEFT OUTER JOIN UNI.PREREQ P
ON U.UNITCODE = P.UNITCODE
GROUP BY U.UNITCODE, U.UNITNAME
HAVING COUNT(PREREQUNITCODE) = 0
ORDER BY UNITCODE;


/* Using set operator MINUS */
SELECT U.UNITCODE, U.UNITNAME FROM UNI.UNIT U 
MINUS
SELECT U.UNITCODE, UNITNAME FROM UNI.UNIT U JOIN UNI.PREREQ P
ON U.UNITCODE = P.UNITCODE
ORDER BY UNITCODE;



/* Using subquery */





--5



--6



--7



--8
    

    
--9


    
--10







