/*
Database Teaching Team
applied9_sql_basic.sql

student id: 33396973
student name:Han Si Yi
last modified date:

*/

/* Part A - Retrieving data from a single table */

-- A1
SELECT *
FROM uni.student 
ORDER BY unitcode;

-- A2
SELECT *
FROM uni.student 
WHERE UPPER(studaddress) LIKE UPPER ('%Caulfield%')
ORDER BY stuid;

-- A3
SELECT stuid, stulname, stufname, stuaddress
FROM uni.student
WHERE upper(stulname) LIKE 'S%'
AND UPPER (stufname) LIKE '%i%'
ORDER BY stuid;

-- A4
SELECT stuid,
       stulname,
       stufname,
       studaddress
  FROM uni.student
 WHERE upper(stulname) LIKE 's%'
   AND upper(stufname) LIKE '%i%'
 ORDER BY stuid;



-- A5




-- A6
SELECT unitcode,
       ofsemester
  FROM uni.offering
 WHERE to_char(
    ofyear,
    'yyyy'
) = '2021'
 ORDER BY unitcode,
          ofsemester;

-- A7
SELECT unitcode, ofyear
FROM uni.offering
WHERE ofsemester = 2 AND (to_char(ofyear, 'yyyy') = '2019' OR to_char(ofyear, 'yyyy') = '2020')
ORDER BY unitcode, ofyear;

-- A8
SELECT stuid,
       unitcode,
       enrolmark
  FROM uni.enrolment
 WHERE ofsemester = 2
   AND to_char(
    ofyear,
    'yyyy'
) = '2021'
   AND enrolmark < 50
 ORDER BY stuid,
          unitcode;


-- A9
SELECT stuid
  FROM uni.enrolment
 WHERE ofsemester = 1
   AND to_char(
    ofyear,
    'yyyy'
) = 2020
   AND unitcode = 'FIT3176'
   AND enrolmark IS NULL
   AND enrolgrade IS NULL
 ORDER BY stuid;


/* Part B - Retrieving data from multiple tables */

-- B1
SELECT unitcode,
       ofsemester,
       stafffname,
       stafflname
  FROM uni.offering o
  JOIN uni.staff s
ON s.staffid = o.STAFFID
 WHERE to_char(
    ofyear,
    'yyyy'
) = '2021'
 ORDER BY ofsemester,
          unitcode;


-- B2
select unitcode, unitname, ofsemester, ofyear
from uni.offering o JOIN uni.unitcode ON u.unitcode = o.UNITCODE
order by u.unitcode, year, o.ofsemester;

-- B3
SELECT e.stuid,
       stufname
       || ''
       || stulname as stuname,
       unitname
  FROM uni.student s
  JOIN uni.enrolment e
ON s.stuid = e.stuid
  JOIN uni.unit u
ON u.unitcode = e.unitcode
 WHERE ofsemester = 1
   AND to_char(
    ofyear,
    'yyyy'
) = '2021'
 ORDER BY unitname;

-- B4
SELECT e.stuid,
       stufname
       || ' '
       || stulname AS stuname
  FROM uni.student s
  JOIN uni.enrolment e
ON s.stuid = e.stuid
 WHERE e.unitcode = 'FIT9132'
   AND ofsemester = 2
   AND to_char(
    ofyear,
    'yyyy'
) = '2019'
   AND enrolmark BETWEEN 80 AND 100
 ORDER BY stuname,
          e.stuid;

-- B5




-- B6
select e.unitcode, unitname, ofsemester, to_char(ofyear, 'yyyy') as year,
nvl(to_char(enrolmark, '999'),'N/A') as mark, 
nvl(enrolgrade, 'N/A') as grade
from uni.student s JOIN uni.enrolment e on s.stuid = e.STUID
JOIN uni.unit u on u.unitcode = e.UNITCODE
where upper(stufname) = upper('Brier') and upper(stulname) = upper('Kilgour')
order by year, ofsemester, unitcode;


-- B7


-- B8


-- B9


-- B10
