--****PLEASE ENTER YOUR DETAILS BELOW****
--T3-rm-dm.sql

--Student ID:33396973
--Student Name:Han Si Yi

/* Comments for your marker:




*/

--(a)
DROP SEQUENCE competitor_seq;

DROP SEQUENCE team_seq;

CREATE SEQUENCE competitor_seq START WITH 100 INCREMENT BY 5;

CREATE SEQUENCE team_seq START WITH 100 INCREMENT BY 5;
COMMIT;


--(b)
INSERT INTO COMPETITOR VALUES (
    COMPETITOR_SEQ.NEXTVAL,
    'Keith',
    'Rose',
    'F',
    TO_DATE('01-JAN-1995','DD-MM-YYYY'),
    'keith.rose@outlook.com',
    'Y',
    '0422141112'
);

INSERT INTO COMPETITOR VALUES (
    COMPETITOR_SEQ.NEXTVAL,
    'Jackson',
    'Bull',
    'M',
    TO_DATE('01-OCT-1995','DD-MM-YYYY'),
    'JacksonwithBull@outlook.com',
    'Y',
    '0422412524'
);



INSERT INTO entry (
    event_id, entry_no, entry_starttime, entry_finishtime, entry_elapsedtime,
    comp_no, team_id, char_id
)
SELECT
    e.event_id,
    1,
    TO_DATE('08:30:00','HH24:MI:SS'),
    TO_DATE('09:30:00','HH24:MI:SS'),
    TO_DATE('01:00:00','HH24:MI:SS'),
    100,               
    NULL,              
    ch.char_id
FROM event e
JOIN carnival c ON e.carn_date = c.carn_date
JOIN eventtype t ON e.eventtype_code = t.eventtype_code
JOIN charity ch ON ch.char_name = 'Salvation Army'
WHERE c.carn_name = 'RM Winter Series Caulfield 2025'
  AND t.eventtype_desc = '10 Km Run';

INSERT INTO team (
    team_id, team_name, carn_date, event_id, entry_no
)
SELECT
    TEAM_SEQ.NEXTVAL, 'Super Runners', e.carn_date, e.event_id, 1
FROM event e
JOIN carnival c ON e.carn_date = c.carn_date
JOIN eventtype t ON e.eventtype_code = t.eventtype_code
WHERE c.carn_name = 'RM Winter Series Caulfield 2025'
  AND t.eventtype_desc = '10 Km Run';

UPDATE entry
SET team_id = (
    SELECT team_id
    FROM team
    WHERE team_name = 'Super Runners'
      AND event_id = entry.event_id
      AND entry_no = 1
)
WHERE comp_no = 100
  AND entry_no = 1;

INSERT INTO entry (
    event_id, entry_no, entry_starttime, entry_finishtime, entry_elapsedtime,
    comp_no, team_id, char_id
)
SELECT
    e.event_id,
    2,
    TO_DATE('08:35:00','HH24:MI:SS'),
    TO_DATE('09:35:00','HH24:MI:SS'),
    TO_DATE('01:00:00','HH24:MI:SS'),
    105,              
    (SELECT team_id
     FROM team
     WHERE team_name = 'Super Runners'
       AND e.event_id = team.event_id),
    ch.char_id
FROM event e
JOIN carnival c ON e.carn_date = c.carn_date
JOIN eventtype t ON e.eventtype_code = t.eventtype_code
JOIN charity ch ON ch.char_name = 'RSPCA'
WHERE c.carn_name = 'RM Winter Series Caulfield 2025'
  AND t.eventtype_desc = '10 Km Run';
COMMIT;

--(c)
UPDATE entry
SET event_id = (
    SELECT e.event_id
    FROM event e
    JOIN carnival c ON e.carn_date = c.carn_date
    JOIN eventtype et ON e.eventtype_code = et.eventtype_code
    WHERE c.carn_name = 'RM Winter Series Caulfield 2025'
      AND et.eventtype_desc = '5 Km Run'
),
    char_id = (
    SELECT ch.char_id
    FROM charity ch
    WHERE ch.char_name = 'Beyond Blue'
)
WHERE comp_no = (
    SELECT comp_no
    FROM competitor
    WHERE comp_fname = 'Jackson' AND comp_lname = 'Bull'
)
AND event_id = (
    SELECT e.event_id
    FROM event e
    JOIN carnival c ON e.carn_date = c.carn_date
    JOIN eventtype et ON e.eventtype_code = et.eventtype_code
    WHERE c.carn_name = 'RM Winter Series Caulfield 2025'
      AND et.eventtype_desc = '10 Km Run'
);

COMMIT;





--(d)
UPDATE entry
SET team_id = NULL
WHERE team_id = (
    SELECT team_id
    FROM team
    WHERE team_name = 'Super Runners'
      AND carn_date = (
          SELECT carn_date
          FROM carnival
          WHERE carn_name = 'RM Winter Series Caulfield 2025'
      )
);


DELETE FROM team
WHERE team_name = 'Super Runners'
  AND carn_date = (
      SELECT carn_date
      FROM carnival
      WHERE carn_name = 'RM Winter Series Caulfield 2025'
  );


DELETE FROM entry
WHERE comp_no = (
    SELECT comp_no
    FROM competitor
    WHERE comp_fname = 'Keith' AND comp_lname = 'Rose'
)
AND event_id = (
    SELECT e.event_id
    FROM event e
    JOIN carnival c ON e.carn_date = c.carn_date
    JOIN eventtype et ON e.eventtype_code = et.eventtype_code
    WHERE c.carn_name = 'RM Winter Series Caulfield 2025'
      AND et.eventtype_desc = '10 Km Run'
);


COMMIT;
