--****PLEASE ENTER YOUR DETAILS BELOW****
--T4-rm-mods.sql

--Student ID:33396973
--Student Name:Han Si Yi

/* Comments for your marker:




*/

--(a)
ALTER TABLE competitor ADD comp_eventcompleted NUMBER(3);

COMMENT ON COLUMN competitor.comp_eventcompleted IS
    'Total number of events completed by the competitor';

UPDATE competitor c
SET comp_eventcompleted = (
    SELECT COUNT(*)
    FROM entry e
    WHERE e.comp_no = c.comp_no
      AND e.entry_finishtime IS NOT NULL
);

DESC competitor;


SELECT comp_no, comp_fname, comp_lname, comp_eventcompleted
FROM competitor
ORDER BY comp_no;

COMMIT;




--(b)
DROP TABLE entry_charity CASCADE CONSTRAINTS;
CREATE TABLE entry_charity (
    event_id    NUMBER(6) NOT NULL,
    entry_no    NUMBER(5) NOT NULL,
    char_id     NUMBER(3) NOT NULL,
    percent     NUMBER(3) CHECK (percent BETWEEN 0 AND 100)
);

ALTER TABLE entry_charity ADD CONSTRAINT entry_charity_pk PRIMARY KEY (event_id, entry_no, char_id);

ALTER TABLE entry_charity
    ADD CONSTRAINT ec_fk_entry FOREIGN KEY (event_id, entry_no)
        REFERENCES entry (event_id, entry_no);

ALTER TABLE entry_charity
    ADD CONSTRAINT ec_fk_charity FOREIGN KEY (char_id)
        REFERENCES charity (char_id);

COMMENT ON COLUMN entry_charity.event_id IS
    'Event ID for the entry';

COMMENT ON COLUMN entry_charity.entry_no IS
    'Entry number for the competitor';

COMMENT ON COLUMN entry_charity.char_id IS
    'Charity supported by the entry';

COMMENT ON COLUMN entry_charity.percent IS
    'Percentage of funds allocated to the charity';


INSERT INTO entry_charity
SELECT
    e.event_id, e.entry_no,
    (SELECT char_id FROM charity WHERE char_name = 'RSPCA'),
    70
FROM entry e
JOIN competitor c ON e.comp_no = c.comp_no
JOIN event ev ON e.event_id = ev.event_id
JOIN carnival ca ON ev.carn_date = ca.carn_date
WHERE c.comp_fname = 'Jackson' AND c.comp_lname = 'Bull'
  AND ca.carn_name = 'RM Winter Series Caulfield 2025';

INSERT INTO entry_charity
SELECT
    e.event_id, e.entry_no,
    (SELECT char_id FROM charity WHERE char_name = 'Beyond Blue'),
    30
FROM entry e
JOIN competitor c ON e.comp_no = c.comp_no
JOIN event ev ON e.event_id = ev.event_id
JOIN carnival ca ON ev.carn_date = ca.carn_date
WHERE c.comp_fname = 'Jackson' AND c.comp_lname = 'Bull'
  AND ca.carn_name = 'RM Winter Series Caulfield 2025';


DESC entry_charity;

SELECT * FROM entry_charity;

COMMIT;