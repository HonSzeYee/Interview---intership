/*****PLEASE ENTER YOUR DETAILS BELOW*****/
--T2-rm-insert.sql

--Student ID:33396973
--Student Name:HanSiYi

/* Comments for your marker:




*/

-- Task 2 Load the COMPETITOR, ENTRY and TEAM tables with your own
-- test data following the data requirements expressed in the brief




-- =======================================
-- COMPETITOR
-- =======================================
INSERT INTO COMPETITOR VALUES (
    00001,
    'Yu Qi',
    'Zhang',
    'F',
    TO_DATE('1981-09-10', 'yyyy-mm-dd'),
    'yuqizhang@gmail.com',
    'N',
    '0127664696'
);

INSERT INTO COMPETITOR VALUES (
    00002,
    'Fang Wai',
    'Foo',
    'M',
    TO_DATE('1964-05-27', 'yyyy-mm-dd'),
    'fwoo2@gmail.com',
    'N',
    '0127160457'
);

INSERT INTO COMPETITOR VALUES (
    00003,
    'Chun Yu',
    'Lo',
    'M',
    TO_DATE('2002-08-19', 'yyyy-mm-dd'),
    'ansonlo@gmail.com',
    'N',
    '5264802952'
);

INSERT INTO COMPETITOR VALUES (
    00004,
    'Shu Han',
    'Liu',
    'F',
    TO_DATE('2002-01-19', 'yyyy-mm-dd'),
    'shuhanyeah@gmail.com',
    'N',
    '0137140184'
);

INSERT INTO COMPETITOR VALUES (
    00005,
    'Qi Jun',
    'Foo',
    'F',
    TO_DATE('2004-10-09', 'yyyy-mm-dd'),
    'qijunfoo2@gmail.com',
    'N',
    '0175556642'
);

INSERT INTO COMPETITOR VALUES (
    00006,
    'Si Yi',
    'Han',
    'F',
    TO_DATE('2002-11-01', 'yyyy-mm-dd'),
    'shan0076@student.monash.edu',
    'Y',
    '0179895241'
);

INSERT INTO COMPETITOR VALUES (
    00007,
    'Huey Fang',
    'Ong',
    'F',
    TO_DATE('1971-01-01', 'yyyy-mm-dd'),
    'ong.hueyfang@monash.edu',
    'Y',
    '0355146001'
);

INSERT INTO COMPETITOR VALUES (
    00008,
    'Fung Fung',
    'Ting',
    'F',
    TO_DATE('1991-09-15', 'yyyy-mm-dd'),
    'ting.fung@monash.edu',
    'Y',
    '0355145898'
);

INSERT INTO COMPETITOR VALUES (
    00009,
    'Teng Sian',
    'Ong',
    'M',
    TO_DATE('1993-08-17', 'yyyy-mm-dd'),
    'ong.tengsian@monash.edu',
    'Y',
    '0355148525'
);

INSERT INTO COMPETITOR VALUES (
    00010,
    'Anthony',
    'Guo',
    'M',
    TO_DATE('1976-06-06', 'yyyy-mm-dd'),
    'anthony.guo@monash.edu',
    'Y',
    '0355146243'
);

INSERT INTO COMPETITOR VALUES (
    00011,
    'Wai Mun',
    'Tang',
    'F',
    TO_DATE('1981-04-06', 'yyyy-mm-dd'),
    'Tang.WaiMun@monash.edu',
    'Y',
    '0355144640'
);

INSERT INTO COMPETITOR VALUES (
    00012,
    'Run Min',
    'Feng',
    'M',
    TO_DATE('2002-03-05', 'yyyy-mm-dd'),
    'runminfeng@icloud.com',
    'N',
    '0126365262'
);

INSERT INTO COMPETITOR VALUES (
    00013,
    'Chloe',
    'Lim',
    'F',
    TO_DATE('2002-03-15', 'yyyy-mm-dd'),
    'hsylzr0819@gmail.com',
    'N',
    '0198584532'
);

INSERT INTO COMPETITOR VALUES (
    00014,
    'Jack',
    'Lim',
    'M',
    TO_DATE('2002-10-11', 'yyyy-mm-dd'),
    'fooffzhangyq@yahoo.com',
    'N',
    '0123458547'
);

INSERT INTO COMPETITOR VALUES (
    00015,
    'Emily',
    'Tan',
    'M',
    TO_DATE('2005-05-16', 'yyyy-mm-dd'),
    'emilydoctorchin@yahoo.com',
    'N',
    '0156325232'
);





-- =======================================
-- ENTRY
-- =======================================
INSERT INTO entry VALUES (3, 1, TO_DATE('09:01','hh24:mi'), TO_DATE('10:01','hh24:mi'), TO_DATE('01:00','hh24:mi'), 1, NULL, 4);
INSERT INTO entry VALUES (5, 1, TO_DATE('09:01','hh24:mi'), TO_DATE('10:01','hh24:mi'), TO_DATE('01:00','hh24:mi'), 2, NULL, 3);
INSERT INTO entry VALUES (1, 1, TO_DATE('09:01','hh24:mi'), TO_DATE('10:01','hh24:mi'), TO_DATE('01:00','hh24:mi'), 3, NULL, 1);
INSERT INTO entry VALUES (5, 2, TO_DATE('09:02','hh24:mi'), TO_DATE('10:02','hh24:mi'), TO_DATE('01:00','hh24:mi'), 4, NULL, 1);
INSERT INTO entry VALUES (3, 2, TO_DATE('09:02','hh24:mi'), TO_DATE('10:02','hh24:mi'), TO_DATE('01:00','hh24:mi'), 5, NULL, 4);
INSERT INTO entry VALUES (2, 1, TO_DATE('09:01','hh24:mi'), TO_DATE('10:01','hh24:mi'), TO_DATE('01:00','hh24:mi'), 6, NULL, 1);
INSERT INTO entry VALUES (2, 2, TO_DATE('09:02','hh24:mi'), TO_DATE('10:02','hh24:mi'), TO_DATE('01:00','hh24:mi'), 7, NULL, 1);
INSERT INTO entry VALUES (3, 3, TO_DATE('09:03','hh24:mi'), TO_DATE('10:03','hh24:mi'), TO_DATE('01:00','hh24:mi'), 8, NULL, 3);
INSERT INTO entry VALUES (4, 1, TO_DATE('09:01','hh24:mi'), TO_DATE('10:01','hh24:mi'), TO_DATE('01:00','hh24:mi'), 9, NULL, 3);
INSERT INTO entry VALUES (6, 1, TO_DATE('09:01','hh24:mi'), TO_DATE('10:01','hh24:mi'), TO_DATE('01:00','hh24:mi'), 10, NULL, 4);
INSERT INTO entry VALUES (1, 2, TO_DATE('09:02','hh24:mi'), TO_DATE('10:02','hh24:mi'), TO_DATE('01:00','hh24:mi'), 11, NULL, 2);
INSERT INTO entry VALUES (4, 2, TO_DATE('09:02','hh24:mi'), TO_DATE('10:02','hh24:mi'), TO_DATE('01:00','hh24:mi'), 12, NULL, 1);
INSERT INTO entry VALUES (1, 3, TO_DATE('09:03','hh24:mi'), TO_DATE('10:03','hh24:mi'), TO_DATE('01:00','hh24:mi'), 13, NULL, 1);
INSERT INTO entry VALUES (2, 3, TO_DATE('09:03','hh24:mi'), TO_DATE('10:03','hh24:mi'), TO_DATE('01:00','hh24:mi'), 14, NULL, 2);
INSERT INTO entry VALUES (3, 4, TO_DATE('09:04','hh24:mi'), TO_DATE('10:04','hh24:mi'), TO_DATE('01:00','hh24:mi'), 15, NULL, 3);
INSERT INTO entry VALUES (5, 3, TO_DATE('09:03','hh24:mi'), TO_DATE('10:03','hh24:mi'), NULL, 5, NULL, 3);
INSERT INTO entry VALUES (6, 2, TO_DATE('09:02','hh24:mi'), TO_DATE('10:02','hh24:mi'), TO_DATE('01:00','hh24:mi'), 4, NULL, 1);
INSERT INTO entry VALUES (6, 3, TO_DATE('09:03','hh24:mi'), TO_DATE('10:03','hh24:mi'), TO_DATE('01:00','hh24:mi'), 2, NULL, 2);
INSERT INTO entry VALUES (4, 3, TO_DATE('09:03','hh24:mi'), TO_DATE('10:03','hh24:mi'), NULL, 1, NULL, 4);
INSERT INTO entry VALUES (5, 4, TO_DATE('09:04','hh24:mi'), TO_DATE('10:04','hh24:mi'), TO_DATE('01:00','hh24:mi'), 8, NULL, 2);
INSERT INTO entry VALUES (1, 4, TO_DATE('09:04','hh24:mi'), TO_DATE('10:04','hh24:mi'), TO_DATE('01:00','hh24:mi'), 7, NULL, 2);
INSERT INTO entry VALUES (3, 5, TO_DATE('09:05','hh24:mi'), TO_DATE('10:05','hh24:mi'), TO_DATE('01:00','hh24:mi'), 6, NULL, 1);
INSERT INTO entry VALUES (4, 4, TO_DATE('09:04','hh24:mi'), TO_DATE('10:04','hh24:mi'), TO_DATE('01:00','hh24:mi'), 3, NULL, 4);
INSERT INTO entry VALUES (5, 5, TO_DATE('09:05','hh24:mi'), TO_DATE('10:05','hh24:mi'), TO_DATE('01:00','hh24:mi'), 10, NULL, 2);
INSERT INTO entry VALUES (6, 4, TO_DATE('09:04','hh24:mi'), TO_DATE('10:04','hh24:mi'), TO_DATE('01:00','hh24:mi'), 11, NULL, 1);
INSERT INTO entry VALUES (2, 4, TO_DATE('09:04','hh24:mi'), TO_DATE('10:04','hh24:mi'), TO_DATE('01:00','hh24:mi'), 12, NULL, 4);
INSERT INTO entry VALUES (1, 5, TO_DATE('09:05','hh24:mi'), TO_DATE('10:05','hh24:mi'), TO_DATE('01:00','hh24:mi'), 9, NULL, 3);
INSERT INTO entry VALUES (3, 6, TO_DATE('09:06','hh24:mi'), TO_DATE('10:06','hh24:mi'), TO_DATE('01:00','hh24:mi'), 13, NULL, 3);
INSERT INTO entry VALUES (4, 5, TO_DATE('09:05','hh24:mi'), TO_DATE('10:05','hh24:mi'), TO_DATE('01:00','hh24:mi'), 14, NULL, 2);
INSERT INTO entry VALUES (5, 6, TO_DATE('09:06','hh24:mi'), TO_DATE('10:06','hh24:mi'), TO_DATE('01:00','hh24:mi'), 15, NULL, 2);


-- =======================================
-- TEAM
-- =======================================
INSERT INTO TEAM VALUES (1, 'Coyotes', TO_DATE('22/SEP/2024','DD/MON/YYYY'), 1, 1);
INSERT INTO TEAM VALUES (2, 'Coyotes', TO_DATE('05/OCT/2024','DD/MON/YYYY'), 3, 1);
INSERT INTO TEAM VALUES (3, 'Tigers', TO_DATE('05/OCT/2024','DD/MON/YYYY'), 4, 2);
INSERT INTO TEAM VALUES (4, 'Dragons', TO_DATE('29/JUN/2025','DD/MON/YYYY'), 5, 2);
INSERT INTO TEAM VALUES (5, 'Eagles', TO_DATE('29/JUN/2025','DD/MON/YYYY'), 6, 1);

UPDATE entry SET team_id = 1 WHERE event_id IN (3, 4, 5);
UPDATE entry SET team_id = 2 WHERE event_id IN (1, 2);
UPDATE entry SET team_id = 3 WHERE event_id = 5;
UPDATE entry SET team_id = 4 WHERE event_id IN (2, 4, 5);
UPDATE entry SET team_id = 5 WHERE event_id IN (1, 3, 6);

COMMIT;