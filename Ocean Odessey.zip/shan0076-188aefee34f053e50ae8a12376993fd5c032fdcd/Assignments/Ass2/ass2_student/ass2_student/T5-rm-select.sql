/*****PLEASE ENTER YOUR DETAILS BELOW*****/
--T5-rm-select.sql

--Student ID:33396973
--Student Name:Han Si Yi


/* Comments for your marker:




*/


/* (a) */
-- PLEASE PLACE REQUIRED SQL SELECT STATEMENT FOR THIS PART HERE
-- ENSURE that your query is formatted and has a semicolon
-- (;) at the end of this answer
SELECT
    t.team_name AS TEAM_NAME,
    t.carn_date AS CARNIVAL_DATE,
    (SELECT c2.comp_fname || ' ' || c2.comp_lname
     FROM entry e2
     JOIN competitor c2 ON e2.comp_no = c2.comp_no
     WHERE e2.event_id = t.event_id
       AND e2.entry_no = t.entry_no
    ) AS TEAMLEADER,
    COUNT(e.comp_no) AS TEAM_NO_MEMBERS
FROM team t
JOIN entry e ON t.team_id = e.team_id
GROUP BY t.team_name, t.carn_date, t.event_id, t.entry_no
ORDER BY t.team_name, t.carn_date;






/* (b) */
-- PLEASE PLACE REQUIRED SQL SELECT STATEMENT FOR THIS PART HERE
-- ENSURE that your query is formatted and has a semicolon
-- (;) at the end of this answer
SELECT
    et.eventtype_desc AS "Event",
    c.carn_name || ' held ' || TO_CHAR(c.carn_date, 'Dy DD-Mon-YYYY') AS "Carnival",
    TO_CHAR(ent.entry_elapsedtime, 'HH24:MI:SS') AS "Current Record",
    LPAD(comp.comp_no, 5, '0') || ' ' || comp.comp_fname || ' ' || comp.comp_lname AS "Competitor No and Name",
    FLOOR(MONTHS_BETWEEN(c.carn_date, comp.comp_dob)/12) AS "Age at Carnival"
FROM entry ent
JOIN event e ON ent.event_id = e.event_id
JOIN eventtype et ON e.eventtype_code = et.eventtype_code
JOIN carnival c ON e.carn_date = c.carn_date
JOIN competitor comp ON ent.comp_no = comp.comp_no
WHERE ent.entry_elapsedtime IS NOT NULL
  AND ent.entry_elapsedtime = (
      SELECT MIN(ent2.entry_elapsedtime)
      FROM entry ent2
      JOIN event e2 ON ent2.event_id = e2.event_id
      WHERE ent2.entry_elapsedtime IS NOT NULL
        AND e2.eventtype_code = e.eventtype_code
        AND e2.carn_date = e.carn_date
  )
ORDER BY et.eventtype_desc, comp.comp_no;




/* (c) */
-- PLEASE PLACE REQUIRED SQL SELECT STATEMENT FOR THIS PART HERE
-- ENSURE that your query is formatted and has a semicolon
-- (;) at the end of this answer

WITH entry_counts AS (
  SELECT
    ev.carn_date,
    ev.eventtype_code,
    COUNT(*) AS entry_count
  FROM entry e
  JOIN event ev ON e.event_id = ev.event_id
  GROUP BY ev.carn_date, ev.eventtype_code
),
carnival_totals AS (
  SELECT
    ev.carn_date,
    COUNT(*) AS total_entries
  FROM entry e
  JOIN event ev ON e.event_id = ev.event_id
  GROUP BY ev.carn_date
)
SELECT
  ca.carn_name AS "Carnival Name",
  TO_CHAR(ca.carn_date, 'DD Mon YYYY') AS "Carnival Date",
  et.eventtype_desc AS "Event Description",
  NVL(TO_CHAR(ec.entry_count), 'Not offered') AS "Number of Entries",
  CASE
  WHEN ec.entry_count IS NOT NULL AND ct.total_entries > 0 THEN
    TO_CHAR(ROUND(ec.entry_count * 100 / ct.total_entries)) || '%'
  ELSE
    ''
END AS "% of Carnival Entries"


FROM carnival ca
CROSS JOIN eventtype et
LEFT JOIN entry_counts ec
  ON ec.carn_date = ca.carn_date AND ec.eventtype_code = et.eventtype_code
LEFT JOIN carnival_totals ct
  ON ct.carn_date = ca.carn_date
ORDER BY ca.carn_date,
         NVL(ec.entry_count, 0) DESC,
         et.eventtype_desc;

