set echo on
SPOOL oo_schema_output.txt

--student id: 33396973
--student name: SiYi Han

DROP TABLE CABIN CASCADE CONSTRAINTS 
;

DROP TABLE COUNTRY CASCADE CONSTRAINTS 
;

DROP TABLE CRUISE CASCADE CONSTRAINTS 
;

DROP TABLE MANIFEST CASCADE CONSTRAINTS 
;

DROP TABLE OPERATOR CASCADE CONSTRAINTS 
;

DROP TABLE PASSENGER CASCADE CONSTRAINTS 
;

DROP TABLE PORT CASCADE CONSTRAINTS 
;

DROP TABLE PORT_RECORD CASCADE CONSTRAINTS 
;

DROP TABLE SHIP CASCADE CONSTRAINTS 
;

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE CABIN 
    ( 
     cabin_no                VARCHAR2 (10 CHAR)  NOT NULL , 
     ship_code               VARCHAR2 (10 CHAR)  NOT NULL , 
     cabin_sleeping_capacity NUMBER (6,2)  NOT NULL , 
     cabin_class             VARCHAR2 (20 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE CABIN 
    ADD CONSTRAINT cabin_class_level 
    CHECK (cabin_class IN ('B', 'I', 'OV', 'S')) 
;

COMMENT ON COLUMN CABIN.cabin_no IS 'Cabin number unique within a ship' 
;

COMMENT ON COLUMN CABIN.ship_code IS 'Unique identifier for each ship' 
;

COMMENT ON COLUMN CABIN.cabin_sleeping_capacity IS 'Number of guests the cabin can accommodate' 
;

COMMENT ON COLUMN CABIN.cabin_class IS 'Class of the cabin (Interior, Ocean view, Balcony, Suite)' 
;

ALTER TABLE CABIN 
    ADD CONSTRAINT CABIN_PK PRIMARY KEY ( cabin_no, ship_code ) ;

CREATE TABLE COUNTRY 
    ( 
     country_code VARCHAR2 (10 CHAR)  NOT NULL , 
     country_name VARCHAR2 (50 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE COUNTRY 
    ADD CONSTRAINT COUNTRY_PK PRIMARY KEY ( country_code ) ;

CREATE TABLE CRUISE 
    ( 
     cruise_id           NUMBER (6,2)  NOT NULL , 
     ship_code           VARCHAR2 (10 CHAR)  NOT NULL , 
     cruise_name         VARCHAR2 (100 CHAR)  NOT NULL , 
     cruise_description  VARCHAR2 (200 CHAR) , 
     departure_data_time DATE  NOT NULL , 
     cost_per_person     NUMBER (6,2)  NOT NULL 
    ) 
;

COMMENT ON COLUMN CRUISE.cruise_id IS 'Unique identifier for the cruise' 
;

COMMENT ON COLUMN CRUISE.ship_code IS 'Unique identifier for each ship' 
;

COMMENT ON COLUMN CRUISE.cruise_name IS 'Name of the cruise' 
;

COMMENT ON COLUMN CRUISE.cruise_description IS 'Brief description of the cruise' 
;

COMMENT ON COLUMN CRUISE.departure_data_time IS 'Date and time the cruise departs' 
;

ALTER TABLE CRUISE 
    ADD CONSTRAINT CRUISE_PK PRIMARY KEY ( cruise_id ) ;

CREATE TABLE MANIFEST 
    ( 
     manifest_id        VARCHAR2 (10 CHAR)  NOT NULL , 
     cruise_id          NUMBER (6,2)  NOT NULL , 
     passenger_id       NUMBER (6,2)  NOT NULL , 
     cabin_no           VARCHAR2 (10 CHAR)  NOT NULL , 
     ship_code          VARCHAR2 (10 CHAR)  NOT NULL , 
     boarding_date_time DATE  NOT NULL 
    ) 
;

COMMENT ON COLUMN MANIFEST.manifest_id IS 'Surrogate primary key for MANIFEST' 
;

COMMENT ON COLUMN MANIFEST.cruise_id IS 'Unique identifier for the cruise' 
;

COMMENT ON COLUMN MANIFEST.passenger_id IS 'Unique ID assigned to each passenger

guardian_id - Refers to another passenger acting as guardian for this minor' 
;

COMMENT ON COLUMN MANIFEST.cabin_no IS 'Cabin number unique within a ship' 
;

COMMENT ON COLUMN MANIFEST.ship_code IS 'Unique identifier for each ship' 
;

COMMENT ON COLUMN MANIFEST.boarding_date_time IS 'Date and time the passenger boarded the ship' 
;

ALTER TABLE MANIFEST 
    ADD CONSTRAINT MANIFEST_PK PRIMARY KEY ( manifest_id ) ;

ALTER TABLE MANIFEST 
    ADD CONSTRAINT MANIFEST_NK UNIQUE ( cruise_id , passenger_id , cabin_no , ship_code ) ;

CREATE TABLE OPERATOR 
    ( 
     operator_id  NUMBER (6,2)  NOT NULL , 
     company_name VARCHAR2 (100 CHAR)  NOT NULL , 
     ceo_fname    VARCHAR2 (10 CHAR)  NOT NULL , 
     ceo_lname    VARCHAR2 (10 CHAR)  NOT NULL 
    ) 
;

COMMENT ON COLUMN OPERATOR.operator_id IS 'Unique ID assigned to each ship is operated by a particular company known as the operator.' 
;

COMMENT ON COLUMN OPERATOR.company_name IS 'Name of the operating company' 
;

ALTER TABLE OPERATOR 
    ADD CONSTRAINT OPERATOR_PK PRIMARY KEY ( operator_id ) ;

CREATE TABLE PASSENGER 
    ( 
     passenger_id        NUMBER (10)  NOT NULL , 
     guardian_id         NUMBER (10) , 
     passenger_fname     VARCHAR2 (50 CHAR)  NOT NULL , 
     passenger_lname     VARCHAR2 (50 CHAR)  NOT NULL , 
     passenger_gender    VARCHAR2 (10 CHAR)  NOT NULL , 
     passenger_dob       DATE  NOT NULL , 
     passenger_street    VARCHAR2 (100 CHAR)  NOT NULL , 
     passenger_town      VARCHAR2 (50 CHAR)  NOT NULL , 
     passenger_postcode  VARCHAR2 (10 CHAR)  NOT NULL , 
     passenger_country   VARCHAR2 (50 CHAR)  NOT NULL , 
     passenger_phone_num VARCHAR2 (25 CHAR) 
    ) 
;

COMMENT ON COLUMN PASSENGER.passenger_id IS 'Unique ID assigned to each passenger

guardian_id - Refers to another passenger acting as guardian for this minor' 
;

COMMENT ON COLUMN PASSENGER.guardian_id IS 'Unique ID assigned to each passenger

guardian_id - Refers to another passenger acting as guardian for this minor' 
;

COMMENT ON COLUMN PASSENGER.passenger_fname IS 'Passenger''s first name' 
;

COMMENT ON COLUMN PASSENGER.passenger_lname IS 'Passenger''s last name' 
;

COMMENT ON COLUMN PASSENGER.passenger_gender IS 'Gender of the passenger' 
;

COMMENT ON COLUMN PASSENGER.passenger_dob IS 'Date of birth of the passenger' 
;

COMMENT ON COLUMN PASSENGER.passenger_street IS 'Street address of the passenger' 
;

COMMENT ON COLUMN PASSENGER.passenger_town IS 'Town of the passenger''s residence' 
;

COMMENT ON COLUMN PASSENGER.passenger_postcode IS 'Postcode of the passenger''s address' 
;

COMMENT ON COLUMN PASSENGER.passenger_country IS 'Country of the passenger''s address' 
;

COMMENT ON COLUMN PASSENGER.passenger_phone_num IS 'Passenger’s phone number; minors will use guardian’s phone' 
;

ALTER TABLE PASSENGER 
    ADD CONSTRAINT PASSENGER_PK PRIMARY KEY ( passenger_id ) ;

CREATE TABLE PORT 
    ( 
     port_code       VARCHAR2 (10 CHAR)  NOT NULL , 
     country_code    VARCHAR2 (10 CHAR)  NOT NULL , 
     port_name       VARCHAR2 (50 CHAR)  NOT NULL , 
     port_latitude   VARCHAR2 (50 CHAR) , 
     port_longtitude VARCHAR2 (50 CHAR) 
    ) 
;

ALTER TABLE PORT 
    ADD CONSTRAINT PORT_PK PRIMARY KEY ( port_code, country_code ) ;

CREATE TABLE PORT_RECORD 
    ( 
     port_record_id       VARCHAR2 (10 CHAR)  NOT NULL , 
     cruise_id            NUMBER (6,2)  NOT NULL , 
     port_code            VARCHAR2 (10 CHAR)  NOT NULL , 
     date_and_time        DATE  NOT NULL , 
     departure_or_arrival VARCHAR2 (1 CHAR)  NOT NULL , 
     country_code         VARCHAR2 (10 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE PORT_RECORD 
    ADD CONSTRAINT "chk_dep_arr " 
    CHECK (departure_or_arrival IN ('A', 'D')) 
;

COMMENT ON COLUMN PORT_RECORD.cruise_id IS 'Unique identifier for the cruise' 
;

ALTER TABLE PORT_RECORD 
    ADD CONSTRAINT PORT_RECORD_PK PRIMARY KEY ( port_record_id ) ;

ALTER TABLE PORT_RECORD 
    ADD CONSTRAINT PORT_RECORD_NK UNIQUE ( date_and_time , port_code , cruise_id ) ;

CREATE TABLE SHIP 
    ( 
     ship_code               VARCHAR2 (10 CHAR)  NOT NULL , 
     operator_id             NUMBER (6,2)  NOT NULL , 
     ship_name               VARCHAR2 (100 CHAR)  NOT NULL , 
     ship_commissioned_date  DATE , 
     ship_tonnage            NUMBER (6,2) , 
     ship_max_guest_capacity NUMBER (6,2)  NOT NULL , 
     ship_register_country   VARCHAR2 (50 CHAR)  NOT NULL 
    ) 
;

COMMENT ON COLUMN SHIP.ship_code IS 'Unique identifier for each ship' 
;

COMMENT ON COLUMN SHIP.operator_id IS 'Unique ID assigned to each ship is operated by a particular company known as the operator.' 
;

COMMENT ON COLUMN SHIP.ship_name IS 'Name of the ship' 
;

COMMENT ON COLUMN SHIP.ship_commissioned_date IS 'Date the ship was first commissioned into service' 
;

COMMENT ON COLUMN SHIP.ship_tonnage IS 'Total tonnage of the ship' 
;

COMMENT ON COLUMN SHIP.ship_max_guest_capacity IS 'Maximum number of guests the ship can accommodate' 
;

COMMENT ON COLUMN SHIP.ship_register_country IS 'Country where the ship is officially registered' 
;

ALTER TABLE SHIP 
    ADD CONSTRAINT SHIP_PK PRIMARY KEY ( ship_code ) ;

ALTER TABLE MANIFEST 
    ADD CONSTRAINT cabin_fk FOREIGN KEY 
    ( 
     cabin_no,
     ship_code
    ) 
    REFERENCES CABIN 
    ( 
     cabin_no,
     ship_code
    ) 
;

ALTER TABLE PORT 
    ADD CONSTRAINT country_code_fk FOREIGN KEY 
    ( 
     country_code
    ) 
    REFERENCES COUNTRY 
    ( 
     country_code
    ) 
;

ALTER TABLE MANIFEST 
    ADD CONSTRAINT cruise_id_fk FOREIGN KEY 
    ( 
     cruise_id
    ) 
    REFERENCES CRUISE 
    ( 
     cruise_id
    ) 
;

ALTER TABLE PORT_RECORD 
    ADD CONSTRAINT cruise_id_fkv1 FOREIGN KEY 
    ( 
     cruise_id
    ) 
    REFERENCES CRUISE 
    ( 
     cruise_id
    ) 
;

ALTER TABLE SHIP 
    ADD CONSTRAINT operator_id_fk FOREIGN KEY 
    ( 
     operator_id
    ) 
    REFERENCES OPERATOR 
    ( 
     operator_id
    ) 
;

ALTER TABLE MANIFEST 
    ADD CONSTRAINT passenger_id_fk FOREIGN KEY 
    ( 
     passenger_id
    ) 
    REFERENCES PASSENGER 
    ( 
     passenger_id
    ) 
;

ALTER TABLE PASSENGER 
    ADD CONSTRAINT passenger_id_fk_guardian_id FOREIGN KEY 
    ( 
     guardian_id
    ) 
    REFERENCES PASSENGER 
    ( 
     passenger_id
    ) 
;

ALTER TABLE PORT_RECORD 
    ADD CONSTRAINT port_code_fk FOREIGN KEY 
    ( 
     port_code,
     country_code
    ) 
    REFERENCES PORT 
    ( 
     port_code,
     country_code
    ) 
;

ALTER TABLE CABIN 
    ADD CONSTRAINT ship_code_fk FOREIGN KEY 
    ( 
     ship_code
    ) 
    REFERENCES SHIP 
    ( 
     ship_code
    ) 
;

ALTER TABLE CRUISE 
    ADD CONSTRAINT ship_code_fkv1 FOREIGN KEY 
    ( 
     ship_code
    ) 
    REFERENCES SHIP 
    ( 
     ship_code
    ) 
;

SPOOL off
set echo off


-- Oracle SQL Developer Data Modeler Summary Report: 
-- 
-- CREATE TABLE                             9
-- CREATE INDEX                             0
-- ALTER TABLE                             23
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- TSDP POLICY                              0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
