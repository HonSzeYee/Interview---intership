from __future__ import annotations

from computer import Computer

from data_structures.referential_array import ArrayR
from algorithms.binary_search import binary_search


class ComputerOrganiser:

    def __init__(self) -> None:
        """
        Initialize the ComputerOrganiser with an ArrayR of size 10 and maximum inserted as 0
        """
        self.array = ArrayR(10)
        self.maximum_inserted = 0

    def cur_position(self, computer: Computer) -> int:
        """
        Get the current position of a computer in the array

        Args:
            computer (Computer): The computer to find

        Returns:
            int: The index of the computer in the array

        Raises:
            KeyError: If the computer is not found in the array

        Complexity:
            Best Case: O(1) - If the computer is found in the first comparison
            Worst Case: O(log n) - If the computer is not found and the search requires binary search over the array of size n
        """
        search_list = [(computer.hacking_difficulty, computer.risk_factor, computer.name)
                       for computer in self.array[:self.maximum_inserted]]
        rank = binary_search(
            search_list, (computer.hacking_difficulty, computer.risk_factor, computer.name))
        if self.array[rank] is not None and self.array[rank].name == computer.name:
            return rank
        else:
            raise KeyError("Computer not found")

    def add_computers(self, computers: list[Computer]) -> None:
        """
        Add a list of computers to the array, maintaining a sorted order based on hacking difficulty, risk factor, and name.

        Args:
            computers (list[Computer]): The list of computers to add

        Complexity:
            Best Case: O(n) - Adding n computers to an array with no shifting required
            Worst Case: O(n^2) - Adding n computers to an array with n-1 elements requires shifting elements in the array for each insertion
        """
        new_size = self.maximum_inserted + len(computers)
        if len(self.array) < new_size:
            self.array += [None] * (new_size - len(self.array))

        for new_computer in computers:
            if self.maximum_inserted == 0:
                self.array[0] = new_computer
                self.maximum_inserted += 1
            else:
                search_list = [(computer.hacking_difficulty, computer.risk_factor, computer.name)
                               for computer in self.array[:self.maximum_inserted]]
                insertion_index = binary_search(
                    search_list, (new_computer.hacking_difficulty, new_computer.risk_factor, new_computer.name))
                for i in range(self.maximum_inserted, insertion_index, -1):
                    self.array[i] = self.array[i - 1]
                self.array[insertion_index] = new_computer
                self.maximum_inserted += 1

        if len(self.array) > new_size:
            self.array = self.array[:new_size]
