from __future__ import annotations
from abc import ABC, abstractmethod
from computer import Computer
from data_structures.linked_stack import LinkedStack
from route import Route, RouteSeries, RouteSplit
from branch_decision import BranchDecision


class VirusType(ABC):

    def __init__(self) -> None:
        self.computers = []

    def add_computer(self, computer: Computer) -> None:
        self.computers.append(computer)

    @abstractmethod
    def select_branch(self, top_branch: Route, bottom_branch: Route) -> BranchDecision:
        raise NotImplementedError()


class TopVirus(VirusType):
    def select_branch(self, top_branch: Route, bottom_branch: Route) -> BranchDecision:
        # Always select the top branch
        return BranchDecision.TOP


class BottomVirus(VirusType):
    def select_branch(self, top_branch: Route, bottom_branch: Route) -> BranchDecision:
        # Always select the bottom branch
        return BranchDecision.BOTTOM


class LazyVirus(VirusType):
    def select_branch(self, top_branch: Route, bottom_branch: Route) -> BranchDecision:
        """
        Try looking into the first computer on each branch,
        take the path of the least difficulty.
        """
        top_route = type(top_branch.store) == RouteSeries
        bot_route = type(bottom_branch.store) == RouteSeries

        if top_route and bot_route:
            top_comp = top_branch.store.computer
            bot_comp = bottom_branch.store.computer

            if top_comp.hacking_difficulty < bot_comp.hacking_difficulty:
                return BranchDecision.TOP
            elif top_comp.hacking_difficulty > bot_comp.hacking_difficulty:
                return BranchDecision.BOTTOM
            else:
                return BranchDecision.STOP
        # If one of them has a computer, don't take it.
        # If neither do, then take the top branch.
        if top_route:
            return BranchDecision.BOTTOM
        return BranchDecision.TOP


class RiskAverseVirus(VirusType):
    """
    Time complexity:  best case: O(1).
                      Because it is just basic comparisons and math, and there are no loops.
                      worst case： O(n)
    The virus will go through it by compare the value then do the decision.
    """
    def select_branch(self, top_branch: Route, bottom_branch: Route) -> BranchDecision:
        # Follow Ed logic
        if isinstance(top_branch.store, RouteSeries) and isinstance(bottom_branch.store, RouteSeries):
            top_comp = top_branch.store.computer
            bot_comp = bottom_branch.store.computer

            if top_comp.risk_factor == 0 and bot_comp.risk_factor != 0:
                return BranchDecision.TOP
            elif top_comp.risk_factor != 0 and bot_comp.risk_factor == 0:
                return BranchDecision.BOTTOM
            else:
                if top_comp.hacking_difficulty > bot_comp.hacking_difficulty:
                    return BranchDecision.BOTTOM
                elif top_comp.hacking_difficulty < bot_comp.hacking_difficulty:
                    return BranchDecision.TOP
                elif top_comp.hacking_difficulty == bot_comp.hacking_difficulty:
                    if top_comp.risk_factor != 0:
                        top_value = max(top_comp.hacking_difficulty, int(top_comp.hacked_value / 2)) / top_comp.risk_factor
                    else:
                        top_value = max(top_comp.hacking_difficulty, int(top_comp.hacked_value / 2))

                    if bot_comp.risk_factor != 0:
                        bot_value = max(bot_comp.hacking_difficulty, int(bot_comp.hacked_value / 2)) / bot_comp.risk_factor
                    else:
                        bot_value = max(bot_comp.hacking_difficulty, int(bot_comp.hacked_value / 2))

                    if top_value > bot_value:
                        return BranchDecision.TOP
                    elif bot_value > top_value:
                        return BranchDecision.BOTTOM
                    else:
                        if top_comp.risk_factor < bot_comp.risk_factor:
                            return BranchDecision.TOP
                        elif top_comp.risk_factor > bot_comp.risk_factor:
                            return BranchDecision.BOTTOM
                        else:
                            return BranchDecision.STOP

        elif isinstance(top_branch.store, RouteSeries) and isinstance(bottom_branch.store, RouteSplit):
            return BranchDecision.BOTTOM
        elif isinstance(top_branch.store, RouteSplit) and isinstance(bottom_branch.store, RouteSeries):
            return BranchDecision.TOP

        return BranchDecision.TOP    # If both are RoutSplit - TOP


class FancyVirus(VirusType):
    CALC_STR = "7 3 + 8 - 2 * 2 /"

    def select_branch(self, top_branch: Route, bottom_branch: Route) -> BranchDecision:
        """
        Time complexity:  best case and worst case are O(n).
                          n is the total number of operands and operators in CALC STR.

        The virus will go through it by compare the value then do the decision.
        """
        threshold = self.cal_threshold()

        if isinstance(top_branch.store, RouteSeries):
            top_comp = top_branch.store.computer
        else:
            top_comp = None

        if isinstance(bottom_branch.store, RouteSeries):
            bot_comp = bottom_branch.store.computer
        else:
            bot_comp = None

        if top_comp and bot_comp is not None:
            if top_comp.hacked_value < threshold:
                return BranchDecision.TOP
            elif bot_comp.hacked_value > threshold:
                return BranchDecision.BOTTOM
            else:
                return BranchDecision.STOP
        elif isinstance(top_branch.store, RouteSeries) and isinstance(bottom_branch.store, RouteSplit):
            return BranchDecision.BOTTOM
        elif isinstance(top_branch.store, RouteSplit) and isinstance(bottom_branch.store, RouteSeries):
            return BranchDecision.TOP

        return BranchDecision.TOP

    def cal_threshold(self):
        """
        Time complexity:  best case and worst case are O(n).
                        n is the total number of operands and operators in CALC STR.
        """
        #  Using reverse polish notation. The logic is similar with FIT1045A3.
        operations = self.CALC_STR.split()
        temp_linked_stack = LinkedStack()

        for elem in operations:
            if elem in "+-*/":
                b = temp_linked_stack.pop()
                a = temp_linked_stack.pop()
                if elem == '+':
                    temp_linked_stack.push(a + b)
                elif elem == '-':
                    temp_linked_stack.push(a - b)
                elif elem == '*':
                    temp_linked_stack.push(a * b)
                elif elem == '/':
                    temp_linked_stack.push(a / b)
            else:
                temp_linked_stack.push(float(elem))

        return temp_linked_stack.pop()



