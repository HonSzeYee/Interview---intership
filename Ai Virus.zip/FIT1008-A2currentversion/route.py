from __future__ import annotations
from dataclasses import dataclass

from branch_decision import BranchDecision
from computer import Computer

from typing import TYPE_CHECKING, Union

from data_structures.linked_stack import LinkedStack


# Avoid circular imports for typing.
if TYPE_CHECKING:
    from virus import VirusType


@dataclass
class RouteSplit:
    """
    A split in the route.
       _____top______
      /              \
    -<                >-following-
      \____bottom____/
    """

    top: Route
    bottom: Route
    following: Route

    def remove_branch(self) -> RouteStore:
        """Removes the branch, should just leave the remaining following route."""
        return RouteSeries(self.following.store.computer, Route(None))

@dataclass
class RouteSeries:
    """
    A computer, followed by the rest of the route

    --computer--following--

    """

    computer: Computer
    following: Route

    def remove_computer(self) -> RouteStore:
        """
        Returns a route store which would be the result of:
        Removing the computer at the beginning of this series.
        """
        return self.following.store

    def add_computer_before(self, computer: Computer) -> RouteStore:
        """
        Returns a route store which would be the result of:
        Adding a computer in series before the current one.
        """
        return RouteSeries(computer, Route(RouteSeries(self.computer, self.following)))

    def add_computer_after(self, computer: Computer) -> RouteStore:
        """
        Returns a route store which would be the result of:
        Adding a computer after the current computer, but before the following route.
        """
        return RouteSeries(self.computer, Route(RouteSeries(computer, self.following)))

    def add_empty_branch_before(self) -> RouteStore:
        """Returns a route store which would be the result of:
        Adding an empty branch, where the current routestore is now the following path.
        """
        return RouteSplit(Route(None), Route(None), Route(RouteSeries(self.computer, self.following)))

    def add_empty_branch_after(self) -> RouteStore:
        """
        Returns a route store which would be the result of:
        Adding an empty branch after the current computer, but before the following route.
        """
        return RouteSeries(self.computer, Route(RouteSplit(Route(None), Route(None), self.following)))


RouteStore = Union[RouteSplit, RouteSeries, None]


@dataclass
class Route:
    store: RouteStore = None

    def add_computer_before(self, computer: Computer) -> Route:
        """
        Returns a *new* route which would be the result of:
        Adding a computer before everything currently in the route.
        """
        return Route(RouteSeries(computer, Route(None)))

    def add_empty_branch_before(self) -> Route:
        """
        Returns a *new* route which would be the result of:
        Adding an empty branch before everything currently in the route.
        """
        return Route(RouteSplit(Route(None), Route(None), Route(self.store)))

    def follow_path(self, virus_type: VirusType) -> None:
        """
        Time complexity:  best case: O(1).
                          When decision == BranchDecision.STOP, searching is directly stop.
                          worst case: O(n). n is the number of nodes
                          When each node will be visited once. pop, push O(1)

        """
        # Without recursion.
        # It is Non-recursive depth-first Search (DFS).
        # In order to easily debug, no use Polymorphism (under class Route, RouteSplit, RouteSeries)
        temp_linked_stack = LinkedStack()
        temp_linked_stack.push(self.store)

        while not temp_linked_stack.is_empty():
            current_branch = temp_linked_stack.pop()

            if isinstance(current_branch, RouteSplit):
                decision = virus_type.select_branch(current_branch.top, current_branch.bottom)
                if decision == BranchDecision.TOP:
                    if current_branch.following:
                        temp_linked_stack.push(current_branch.following)
                    temp_linked_stack.push(current_branch.top.store)
                elif decision == BranchDecision.BOTTOM:
                    if current_branch.following:
                        temp_linked_stack.push(current_branch.following)
                    temp_linked_stack.push(current_branch.bottom.store)
                elif decision == BranchDecision.STOP:
                    break

            elif isinstance(current_branch, RouteSeries):
                virus_type.add_computer(current_branch.computer)
                if current_branch.following:
                    temp_linked_stack.push(current_branch.following)

            elif isinstance(current_branch, Route):
                if current_branch.store:
                    temp_linked_stack.push(current_branch.store)

    def add_all_computers(self, current=None) -> list[Computer]:
        """Returns a list of all computers on the route using recursion.

        Time complexity:  best case: O(1).
                          When route is None.
                          worst case: O(n+m). n is the number of nodes, m is the number of computers.
                          When each node will be visited once. 
        """
        if current is None:
            current = self.store

        computers = []
        if isinstance(current, RouteSplit):
            if current.top.store is not None:
                computers.extend(self.add_all_computers(current.top.store))
            if current.bottom.store is not None:
                computers.extend(self.add_all_computers(current.bottom.store))
            if current.following.store is not None:
                computers.extend(self.add_all_computers(current.following.store))
        elif isinstance(current, RouteSeries):
            computers.append(current.computer)
            if current.following.store is not None:
                computers.extend(self.add_all_computers(current.following.store))
        elif isinstance(current, Route):
            if current.store is not None:
                computers.extend(self.add_all_computers(current.store))

        return computers


