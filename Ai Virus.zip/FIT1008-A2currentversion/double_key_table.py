from __future__ import annotations

from typing import Generic, TypeVar, Iterator
from data_structures.hash_table import LinearProbeTable, FullError
from data_structures.referential_array import ArrayR

K1 = TypeVar('K1')
K2 = TypeVar('K2')
V = TypeVar('V')


class DoubleKeyTable(Generic[K1, K2, V]):
    """
    Double Hash Table.

    Type Arguments:
        - K1:   1st Key Type. In most cases should be string.
                Otherwise `hash1` should be overwritten.
        - K2:   2nd Key Type. In most cases should be string.
                Otherwise `hash2` should be overwritten.
        - V:    Value Type.

    Unless stated otherwise, all methods have O(1) complexity.
    """

    # No test case should exceed 1 million entries.
    TABLE_SIZES = [5, 13, 29, 53, 97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157, 98317, 196613, 393241,
                   786433, 1572869]

    HASH_BASE = 31

    def __init__(self, sizes: list | None = None, internal_sizes: list | None = None) -> None:
        if sizes is not None:
            self.TABLE_SIZES = sizes

        if internal_sizes is not None:
            self.internal_sizes = internal_sizes
        else:
            self.internal_sizes = self.TABLE_SIZES

        self.size_index = 0
        self.array: ArrayR[tuple[K1, V] | None] | None = ArrayR(self.TABLE_SIZES[self.size_index])
        self.count = 0

    def hash1(self, key: K1) -> int:
        """
        Hash the 1st key for insert/retrieve/update into the hashtable.

        :complexity: O(len(key))
        """

        value = 0
        a = 31417
        for char in key:
            value = (ord(char) + a * value) % self.table_size
            a = a * self.HASH_BASE % (self.table_size - 1)
        return value

    def hash2(self, key: K2, sub_table: LinearProbeTable[K2, V]) -> int:
        """
        Hash the 2nd key for insert/retrieve/update into the hashtable.

        :complexity: O(len(key))
        """

        value = 0
        a = 31417
        for char in key:
            value = (ord(char) + a * value) % sub_table.table_size
            a = a * self.HASH_BASE % (sub_table.table_size - 1)
        return value

    def _linear_probe(self, key1: K1, key2: K2 | None, is_insert: bool) -> tuple[int, int] | int:
        """
        Find the correct position for this key in the hash table using linear probing.

        :raises KeyError: When the key pair is not in the table, but is_insert is False.
        :raises FullError: When a table is full and cannot be inserted.


        Time Complexity:  best case: O(1)
                          When the top_level_kry meet an empty position
                          worst case: O(n*m)
                          When function may end up probing all available positions
        """

        top_level_key = self.hash1(key1)
        ini_position = top_level_key    # To detect loop when table is full.

        while True:
            cur_position = self.array[top_level_key]
            if cur_position is None:   # When current position is empty.
                if is_insert:    # When insert is True
                    self.array[top_level_key] = (key1, LinearProbeTable(self.internal_sizes))
                    # Ed tips
                    self.array[top_level_key][1].hash = lambda k, tab=self.array[top_level_key][1]: self.hash2(k, tab)
                    if key2 is None:
                        res = top_level_key
                    else:
                        bot_level_key = self.hash2(key2, self.array[top_level_key][1])
                        res = (top_level_key, bot_level_key)
                    return res
                else:  # is_insert is False
                    # raises KeyError: When the key pair is not in the table, but is_insert is False.
                    raise KeyError(f"Top level key {key1} not in the table.")

            if cur_position[0] == key1:
                sub_table = cur_position[1]
                if key2 is not None:
                    bot_level_key = sub_table._linear_probe(key2, is_insert)
                    return top_level_key, bot_level_key
                return top_level_key

            top_level_key = (top_level_key + 1) % len(self.array)
            if top_level_key == ini_position:    # When table is full that is why top_level_key == ini_position.
                # raises FullError: When a table is full and cannot be inserted.
                raise FullError("Top level table is full.")

    def iter_keys(self, key: K1 | None = None) -> Iterator[K1 | K2]:
        """
        key = None:
            Returns an iterator of all top-level keys in hash table
        key = k:
            Returns an iterator of all keys in the bottom-hash-table for k.

        Time Complexity: best case: O(m)/O(n)
                         m is the length of the top level array.
                         When key = None, do not have top level key then the iterator will complete the traversal soon
                         n is the size of the bottom level hash table.
                         When key is the top level key and at the beginning of the position                                        
                         worst case: O(m)/O(n)
                         When key = None, each top level position is occupied.
                         When key is the top level key and at the end of the array.
        """
        copy_arr = self.array[:]

        if key is None:
            for top_key, sub_table in copy_arr:
                if top_key is not None:
                    yield top_key
        else:
            for top_key, sub_table in copy_arr:
                if top_key == key:
                    if sub_table is not None:
                        for sub_key in sub_table.keys():
                            yield sub_key
                    return
            raise KeyError(f"Top level key '{key}' not found.")

    def iter_values(self, key: K1 | None = None) -> Iterator[V]:
        """
        key = None:
            Returns an iterator of all values in hash table
        key = k:
            Returns an iterator of all values in the bottom-hash-table for k.

        Time Complexity:  best case: O(m*n)
                          m is the length of top level array
                          n is the average size of bottom level hash table
                          When key = None, bottom level hash table is empty or none top level key
                          When key is the top level key and iterator the bottom level hash table value
                          worst case: O(m*n)
                          When key = None, all top level position is occupied
                          when Key is the top level key and at the end of the array 
        """
        if key is None:
            for top_key, sub_table in self.array:
                if top_key is not None and sub_table is not None:
                    for value in sub_table.values():
                        yield value
        else:
            for top_key, sub_table in self.array:
                if top_key == key:
                    if sub_table is not None:
                        for value in sub_table.values():
                            yield value
                    return
            raise KeyError(f"Top-level key '{key}' not found.")

    def keys(self, key: K1 | None = None) -> list[K1 | K2]:
        """
        key = None: returns all top-level keys in the table.
        key = x: returns all bottom-level keys for top-level key x.

        Time Complexity: best case: O(m)/O(n)
                         m is the length of top level array
                         n is the size of bottom level hash table
                         When key = None, top level array no valid key
                         When key is the top level key and at the beginning of the array
                         worst case: O(m)/O(n)
                         When key = None, top level array is full, we need check each position
                         When key is the top level key and at the end of the array
        """
        if key is None:
            res = []
            for item in self.array:
                if item is not None:
                    res.append(item[0])
            return res
        else:
            for item in self.array:
                if item is not None and item[0] == key:
                    sub_table = item[1]
                    if sub_table is not None:
                        return sub_table.keys()
                    else:
                        return []
            raise KeyError(f"Top level key '{key}' not found.")

    def values(self, key: K1 | None = None) -> list[V]:
        """
        key = None: returns all values in the table.
        key = x: returns all values for top-level key x.

        Time Complexity:  best case: O(m*n)/O(n)
                          m is the length of top level array
                          n is the average size of bottom level hash table
                          When key = None, bottom level hash table is empty or none top level key
                          When key is the top level which has been found rapidly
                          worst case: O(m*n)/O(n)
                          When key = None, all top level position is occupied
                          when Key is the top level key and at the end of the array 
        """
        if key is None:
            res = []
            for item in self.array:
                if item is not None:
                    sub_table = item[1]
                    res.extend(sub_table.values())
            return res
        else:
            for top_key, sub_table in self.array:
                if top_key == key:
                    if sub_table is not None:
                        return sub_table.values()
                    else:
                        return []
            raise KeyError(f"Top level key '{key}' not found.")

    def __contains__(self, key: tuple[K1, K2]) -> bool:
        """
        Checks to see if the given key is in the Hash Table

        :complexity: See linear probe.
        """
        try:
            _ = self[key]
        except KeyError:
            return False
        else:
            return True

    def __getitem__(self, key: tuple[K1, K2]) -> V:
        """
        Get the value at a certain key

        :raises KeyError: when the key doesn't exist.
        """

        position1, position2 = self._linear_probe(key[0], key[1], False)
        return self.array[position1][1].array[position2][1]

    def __setitem__(self, key: tuple[K1, K2], data: V) -> None:
        """
        Set an (key, value) pair in our hash table.
        """

        key1, key2 = key
        position1, position2 = self._linear_probe(key1, key2, True)
        sub_table = self.array[position1][1]

        if sub_table.is_empty():
            self.count += 1

        sub_table[key2] = data

        # resize if necessary
        if len(self) > self.table_size / 2:
            self._rehash()

    def __delitem__(self, key: tuple[K1, K2]) -> None:
        """
        Deletes a (key, value) pair in our hash table.

        :raises KeyError: when the key doesn't exist.

        Time Complexity: best case: O(1)
                         when the function locates the key1 at top_level_key
                         without any collisions, and the key2 exists directly
                         in the sub table associated with key1
                         worst case: O(n+m)
                         There have multiple collisions for key1 and need rehash.
        """
        key1, key2 = key
        top_level_key = self.hash1(key1)
        ini_position = top_level_key

        while True:
            cur_position = self.array[top_level_key]
            if cur_position is None or cur_position[0] != key1:
                top_level_key = (top_level_key + 1) % len(self.array)
                if top_level_key == ini_position:
                    raise KeyError(f"Top level key '{key1}' not found.")
                continue

            sub_table = cur_position[1]
            if key2 in sub_table:
                del sub_table[key2]
                if len(sub_table) == 0:
                    self.array[top_level_key] = None
                break
            else:
                raise KeyError(f"Key pair ('{key1}', '{key2}') not found.")

        self.count -= 1
        self._rehash()

    def _rehash(self) -> None:
        """
        Need to resize table and reinsert all values

        :complexity best: O(N*hash(K)) No probing.
        :complexity worst: O(N*hash(K) + N^2*comp(K)) Lots of probing.
        Where N is len(self)

        Time Complexity: best case: O(n) 
                         n is the total elements of the hash table
                         when original hash table's elements is less or new hash table size is enough to avoid conflict
                         worst case: O(n^2)
                         use _linear_probe to solve the conflict
        """
        ori_arr = self.array
        self.size_index += 1
        self.count = 0

        if self.size_index >= len(self.TABLE_SIZES):
            self.size_index = len(self.TABLE_SIZES) - 1

        self.array = ArrayR(self.TABLE_SIZES[self.size_index])

        for item in ori_arr:
            if item is not None:
                top_key, sub_table = item
                for key2 in sub_table.keys():
                    value = sub_table[key2]
                    self[(top_key, key2)] = value

    @property
    def table_size(self) -> int:
        """
        Return the current size of the table (different from the length)
        """
        return len(self.array)

    def __len__(self) -> int:
        """
        Returns number of elements in the hash table
        """
        return self.count

    def __str__(self) -> str:
        """
        String representation.

        Not required but may be a good testing tool.
        """
        raise NotImplementedError()




