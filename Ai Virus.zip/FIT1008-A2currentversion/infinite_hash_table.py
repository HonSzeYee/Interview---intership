from __future__ import annotations
from typing import Generic, TypeVar

from data_structures.referential_array import ArrayR


K = TypeVar("K")
V = TypeVar("V")


class InfiniteHashTable(Generic[K, V]):
    """
    Infinite Hash Table.

    Type Arguments:
        - K:    Key Type. In most cases should be string.
                Otherwise `hash` should be overwritten.
        - V:    Value Type.

    Unless stated otherwise, all methods have O(1) complexity.
    """

    TABLE_SIZE = 27

    def __init__(self, level: int = 0) -> None:
        """
        Initialize the InfiniteHashTable

        Args:
            level (int): The level of the hash table (default is 0)

        Complexity:
            Best Case / Worst Case: O(1) - Creating the initial ArrayR object
        """
        self.array: ArrayR[tuple[K, V] | None] = ArrayR(self.TABLE_SIZE)
        self.count = 0
        self.level = level

    def hash(self, key: K) -> int:
        """
        Compute the hash value for a given key

        Args:
            key (K): The key to hash

        Returns:
            int: The computed hash value

        Complexity:
            Best Case / Worse Case: O(1) - Computing the hash value for a key

        """
        if self.level < len(key):
            return ord(key[self.level]) % (self.TABLE_SIZE-1)
        return self.TABLE_SIZE-1

    def __getitem__(self, key: K) -> V:
        """
        Get the value associated with the given key

        Args:
            key (K): The key to look up

        Returns:
            V: The value associated with the key

        Complexity:
            Best Case: O(1) - Finding the key at the first level
            Worst Case: O(n) - Traversing multiple levels to find the key
        """
        current_array = self.array
        hash_position_0, hash_position_1, hash_position_2, hash_position_3, hash_position_4, hash_position_5 = self.hash_key(
            key)
        for index in [hash_position_0, hash_position_1, hash_position_2, hash_position_3, hash_position_4, hash_position_5]:
            if current_array[index][0] == key:
                return current_array[index][1]
            elif isinstance(current_array[index][0], ArrayR):
                current_array = current_array[index]
            else:
                raise KeyError(f"Key '{key}' not found")

    def __setitem__(self, key: K, value: V) -> None:
        """
        Set the value associated with the given key

        Args:
            key (K): The key to set.
            value (V): The value to associate with the key

        Complexity:
            Best Case: O(1) - Setting a value at the first level
            Worst Case: O(n) - Traversing multiple levels to set the value
        """
        current_array = self.array
        hash_position_0, hash_position_1, hash_position_2, hash_position_3, hash_position_4, hash_position_5 = self.hash_key(
            key)
        i = 0
        self.level = 1
        while True:
            index = [hash_position_0, hash_position_1, hash_position_2,
                     hash_position_3, hash_position_4, hash_position_5]

            if current_array[index[i]] is None:
                current_array[index[i]] = (key, value)
                self.count += 1
                break

            elif not isinstance(current_array[index[i]], ArrayR):
                temp = current_array[index[i]]
                current_array[index[i]] = ArrayR(self.TABLE_SIZE)
                hash_position_old = self.hash(temp[0])
                current_array[index[i]][hash_position_old] = temp
                if index[i + 1] == hash_position_old:
                    continue
                current_array[index[i]][index[i + 1]] = (key, value)
                self.count += 1
                break

            else:
                current_array = current_array[index[i]]
                i += 1
                self.level += 1

    def hash_key(self, key):
        """
        Compute hash values for all levels of the key

        Args:
            key: The key to hash

        Returns:
            tuple[int]: Hash values for each level of the key

        Complexity:
            Best Case / Worst Case: O(1) - Computing hash values for all levels
        """
        hash_positions = []
        for i in range(6):
            self.level = i
            hash_position = self.hash(key)
            hash_positions.append(hash_position)
        return tuple(hash_positions)

    def counter_check(self, check, index):
        """
        Check the counter for each level of the index

        Args:
            check: The level to check
            index: The index to check

        Complexity:
            Best Case: O(1) - Checking the counter for a single level
            Worst Case: O(n) - Checking the counter for all levels
        """
        hashed_key_0 = index[0]
        hashed_key_1 = index[1]
        hashed_key_2 = index[2]
        hashed_key_3 = index[3]

        if check == 3:
            self.counter = 0
            for i in range(self.TABLE_SIZE):
                if self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3][i] is not None:
                    temp = self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3][i]
                    self.counter += 1
            if self.counter == 1 and not isinstance(temp, ArrayR):
                self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3] = temp

        elif check == 2:
            self.counter = 0
            for i in range(self.TABLE_SIZE):
                if self.array[hashed_key_0][hashed_key_1][hashed_key_2][i] is not None:
                    temp = self.array[hashed_key_0][hashed_key_1][hashed_key_2][i]
                    self.counter += 1
            if self.counter == 1 and not isinstance(temp, ArrayR):
                self.array[hashed_key_0][hashed_key_1][hashed_key_2] = temp

        elif check == 1:
            self.counter = 0
            for i in range(self.TABLE_SIZE):
                if self.array[hashed_key_0][hashed_key_1][i] is not None:
                    temp = self.array[hashed_key_0][hashed_key_1][i]
                    self.counter += 1
            if self.counter == 1 and not isinstance(temp, ArrayR):
                self.array[hashed_key_0][hashed_key_1] = temp

        elif check == 0:
            self.counter = 0
            for i in range(self.TABLE_SIZE):
                if self.array[hashed_key_0][i] is not None:
                    temp = self.array[hashed_key_0][i]
                    self.counter += 1
            if self.counter == 1 and not isinstance(temp, ArrayR):
                self.array[hashed_key_0] = temp

    def __delitem__(self, key: K) -> None:
        """
        Delete the value associated with the given key

        Args:
            key (K): The key to delete

        Complexity:
            Best Case: O(1) - Deleting a value at the first level
            Worst Case: O(n) - Traversing multiple levels to delete the value
        """
        hashed_key_0, hashed_key_1, hashed_key_2, hashed_key_3, hashed_key_4, hashed_key_5 = self.hash_key(
            key)
        index = [hashed_key_0, hashed_key_1, hashed_key_2,
                 hashed_key_3, hashed_key_4, hashed_key_5]
        num_for_find = len(self.get_location(key))

        if num_for_find == 5:
            self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3][hashed_key_4] = None
            self.count -= 1

            self.counter_check(3, index)
            self.counter_check(2, index)
            self.counter_check(1, index)
            self.counter_check(0, index)

        elif num_for_find == 4:
            self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3] = None
            self.count -= 1

            self.counter_check(2, index)
            self.counter_check(1, index)
            self.counter_check(0, index)

        elif num_for_find == 3:
            self.array[hashed_key_0][hashed_key_1][hashed_key_2] = None
            self.count -= 1

            self.counter_check(1, index)
            self.counter_check(0, index)

        elif num_for_find == 2:

            self.array[hashed_key_0][hashed_key_1] = None
            self.count -= 1

            self.counter_check(0, index)

        elif num_for_find == 1:

            self.array[hashed_key_0] = None
            self.count -= 1

    def __len__(self) -> int:
        """
        Return the number of key-value pairs in the hash table

        Complexity:
            Best Case / Worst Case: O(1) - Returning the count
        """
        return self.count

    def __str__(self) -> str:
        """
        Return a string representation of the hash table

        Returns:
            str: A string representation of the hash table

        Complexity:
            Best Case / Worst Case: O(n) - Converting the array to a string representation
        """
        return str(self.array)

    def get_location(self, key) -> list[int]:
        """
        Get the sequence of positions required to access this key

        Args:
            key: The key to locate

        Returns:
            list[int]: The sequence of positions

        Raises:
            KeyError: If the key is not found

        Complexity:
            Best Case: O(1) - Finding the key at the first level
            Worst Case: O(n) - Traversing multiple levels to find the key
        """

        self.level = 0
        hashed_key_0 = self.hash(key)
        if self.array[hashed_key_0] is not None:
            if self.array[hashed_key_0][0] == key:
                return [hashed_key_0]
            else:
                self.level = 1
                hashed_key_1 = self.hash(key)
                try:
                    if self.array[hashed_key_0][hashed_key_1][0] == key:
                        return [hashed_key_0, hashed_key_1]
                except TypeError:
                    pass
                else:
                    self.level = 2
                    hashed_key_2 = self.hash(key)

                    if self.array[hashed_key_0][hashed_key_1][hashed_key_2][0] == key:
                        return [hashed_key_0, hashed_key_1, hashed_key_2]
                    else:
                        self.level = 3
                        hashed_key_3 = self.hash(key)

                        if self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3][0] == key:
                            return [hashed_key_0, hashed_key_1, hashed_key_2, hashed_key_3]
                        else:
                            self.level = 4
                            hashed_key_4 = self.hash(key)

                            if self.array[hashed_key_0][hashed_key_1][hashed_key_2][hashed_key_3][hashed_key_4][0] == key:
                                return [hashed_key_0, hashed_key_1, hashed_key_2, hashed_key_3, hashed_key_4]
                            else:
                                raise KeyError('Key not found')
        else:
            raise KeyError('Key not found')

        list_for_checking = self.sort_keys()

        correct = 0
        for i in range(len(list_for_checking)):
            if list_for_checking[i][0] == key:
                correct += 1

        if correct == 0:
            raise KeyError('Key not found')

    def __contains__(self, key: K) -> bool:
        """
        Check if the hash table contains the given key

        Args:
            key (K): The key to check

        Returns:
            bool: True if the key is found, False otherwise

        Complexity:
            Best Case: O(1) - Checking for the key at the first level
            Worst Case: O(n) - Traversing multiple levels to check for the key
        """
        try:
            _ = self[key]
        except KeyError:
            return False
        else:
            return True

    def sort_keys(self) -> list[str]:
        """
        Sort the keys in the hash table

        Args:
            current: Not used

        Returns:
            list[str]: The sorted list of keys

        Complexity:
            Best Case: O(n^2) - Sorting the keys in a linear structure
            Worst Case: O(n^3) - Sorting the keys in a fully nested structure
        """
        temp_lst = []
        for i in range(self.TABLE_SIZE):
            if self.array[i] is not None:
                if not isinstance(self.array[i], ArrayR):
                    temp_lst.append(self.array[i][0])
                    continue
                if isinstance(self.array[i], ArrayR):
                    for j in range(self.TABLE_SIZE - 1, 0, -1):
                        if self.array[i][j] is not None:
                            if not isinstance(self.array[i][j], ArrayR):
                                temp_lst.append(self.array[i][j][0])
                                continue
                            if isinstance(self.array[i][j], ArrayR):
                                for k in range(self.TABLE_SIZE):
                                    if self.array[i][j][k] is not None:
                                        if not isinstance(self.array[i][j][k], ArrayR):
                                            temp_lst.append(self.array[i][j][k][0])
                                            continue
                                        if isinstance(self.array[i][j][k], ArrayR):
                                            for l in range(self.TABLE_SIZE - 1, 0, -1):
                                                if self.array[i][j][k][l] is not None:
                                                    if not isinstance(self.array[i][j][k][l], ArrayR):
                                                        temp_lst.append(
                                                            self.array[i][j][k][l][0])
                                                        continue
                                                    if isinstance(self.array[i][j][k][l], ArrayR):
                                                        for m in range(self.TABLE_SIZE):
                                                            if self.array[i][j][k][l][m] is not None:
                                                                if not isinstance(self.array[i][j][k][l][m], ArrayR):
                                                                    temp_lst.append(
                                                                        self.array[i][j][k][l][m][0])

        return temp_lst

