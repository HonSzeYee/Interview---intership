from __future__ import annotations
from computer import Computer

class ComputerManager:

    def __init__(self) -> None:
        """
        Initialize the ComputerManager with an empty list of computers
        """
        self.computer_manager = []

    def add_computer(self, computer: Computer) -> None:
        """
        Add a computer to the manager

        Args:
            computer (Computer): The computer to add

        Complexity:
            Best Case: O(1) - Adding to the end of a list
            Worst Case: O(n) - List needs to resize
        """
        self.computer_manager.append(computer)

    def remove_computer(self, computer: Computer) -> None:
        """
        Remove a computer from the manager

        Args:
            computer (Computer): The computer to remove

        Complexity:
            Best Case: O(1) - Removing the first element
            Worst Case: O(n) - Removing the last element
        """
        for computers in self.computer_manager:
            if computers == computer:
                self.computer_manager.remove(computer)

    def edit_computer(self, old: Computer, new: Computer) -> None:
        """
        Edit a computer in the manager

        Args:
            old (Computer): The old computer to replace
            new (Computer): The new computer to insert

        Complexity:
            Best Case: O(1) - If the old computer is the first element in the list
            Worst Case: O(n) - If the old computer is the last element or not in the list
        """
        for computer in self.computer_manager:
            if computer == old:
                self.computer_manager.remove(old)
                self.computer_manager.append(new)

    def computers_with_difficulty(self, diff: int) -> list[Computer]:
        """
        Get a list of computers with a specific hacking difficulty

        Args:
            diff (int): The hacking difficulty to filter by

        Returns:
            list[Computer]: A list of computers with the specified difficulty

        Complexity:
            Best Case: O(1) - If there are no computers with the specified difficulty
            Worst Case: O(n) - If all computers have the specified difficulty
        """
        hacking_difficulty = []
        for computer in self.computer_manager:
            if computer.hacking_difficulty == diff:
                hacking_difficulty.append(computer)
        return hacking_difficulty

    def group_by_difficulty(self) -> list[list[Computer]]:
        """
        Group computers by hacking difficulty

        Returns:
            list[list[Computer]]: A list of lists, each containing computers with the same hacking difficulty

        Complexity:
            Best Case: O(n) - If all computers have the same hacking difficulty
            Worst Case: O(n * m) - If each computer has a unique hacking difficulty
        """
        group_difficulty = []

        for i in range(10):
            hacking_difficulty = []
            for computer in self.computer_manager:
                if computer.hacking_difficulty == i:
                    hacking_difficulty.append(computer)
            group_difficulty.append(hacking_difficulty)

        removed_empty_list = []
        for difficulty in group_difficulty:
            if difficulty:
                removed_empty_list.append(difficulty)
        return removed_empty_list

