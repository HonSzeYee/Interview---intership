from __future__ import annotations
import random

from data_structures.stack_adt import ArrayStack
from poke_team import Trainer, PokeTeam
from typing import Tuple
from battle_mode import BattleMode
from math import ceil


#  一直在写的版本 94/24 2:35pm
# Apr 10:  1:41pm

class Battle:

    def __init__(self, trainer_1: Trainer, trainer_2: Trainer, battle_mode: BattleMode, criterion="health") -> None:
        self.trainer_1 = trainer_1
        self.trainer_2 = trainer_2
        self.battle_mode = battle_mode
        self.criterion = criterion

    def commence_battle(self) -> Trainer | None:
        if self.battle_mode == BattleMode.SET:
            winning_team = self.set_battle()
        elif self.battle_mode == BattleMode.ROTATE:
            winning_team = self.rotate_battle()
        else:
            winning_team = self.optimise_battle()
        if winning_team is None:
            return None
        elif winning_team == self.trainer_1.team:
            return self.trainer_1
        elif winning_team == self.trainer_2.team:
            return self.trainer_2

    def _create_teams(self) -> None:
        self.trainer_1.pick_team('random')
        self.trainer_2.pick_team('random')

        self.trainer_1.team.assemble_team(self.battle_mode, self.criterion)
        self.trainer_2.team.assemble_team(self.battle_mode, self.criterion)

    def battle_round(self, p1, p2):
        if self.battle_mode == BattleMode.OPTIMISE:
            p1_list_item = p1
            p2_list_item = p2
            p1 = p1.value
            p2 = p2.value
        # """执行一轮战斗，包括攻击和反击逻辑"""
        completion1 = self.trainer_1.get_pokedex_completion()
        completion2 = self.trainer_2.get_pokedex_completion()
        p1_attack_damage = ceil(p1.attack(p2) * (completion1 / completion2))
        p2_attack_damage = ceil(p2.attack(p1) * (completion2 / completion1))

        if p1.speed > p2.speed:
            p2.defend(p1_attack_damage)
            if p2.is_alive():
                p1.defend(p2_attack_damage)
        elif p2.speed > p1.speed:
            p1.defend(p2_attack_damage)
            if p1.is_alive():
                p2.defend(p1_attack_damage)
        elif p1.speed == p2.speed:  # 同时攻击
            p1.defend(p2_attack_damage)
            p2.defend(p1_attack_damage)

        if p1.is_alive() and p2.is_alive():
            p1.health -= 1
            p2.health -= 1

        if self.battle_mode == BattleMode.OPTIMISE:
            self.check_levelup_and_send_back(p1_list_item, p2_list_item)
        else:
            self.check_levelup_and_send_back(p1, p2)

    def check_levelup_and_send_back(self, p1, p2):
        p1_list_item = p1
        p2_list_item = p2
        if self.battle_mode == BattleMode.OPTIMISE:
            p1 = p1.value
            p2 = p2.value

        team_1 = self.trainer_1.get_team()
        team_2 = self.trainer_2.get_team()
        # 检查战斗结果并相应处理
        if p1.is_alive() and not p2.is_alive():
            p1.level_up()
            team_1.send_pokemon_back(p1_list_item)  # Send winner back to the team
            team_2.remove_fainted_pokemon(p2_list_item)
        elif not p1.is_alive() and p2.is_alive():
            p2.level_up()
            team_2.send_pokemon_back(p2_list_item)  # Send winner back to the team
            team_1.remove_fainted_pokemon(p1_list_item)
        elif not p1.is_alive() and not p2.is_alive():  # 记得检查这个情况
            # 如果两个宝可梦都晕厥，处理移除逻辑
            team_1.remove_fainted_pokemon(p1_list_item)
            team_2.remove_fainted_pokemon(p2_list_item)
        elif p1.is_alive() and p2.is_alive():
            team_1.send_pokemon_back(p1_list_item)
            team_2.send_pokemon_back(p2_list_item)

    def set_battle(self) -> PokeTeam | None:
        while not len(self.trainer_1.team) == 0 and not len(self.trainer_2.team) == 0:
            p1 = self.trainer_1.team.get_first_pokemon()  # pop
            p2 = self.trainer_2.team.get_first_pokemon()  # pop

            self.trainer_1.register_pokemon(p2)
            self.trainer_2.register_pokemon(p1)

            self.battle_round(p1, p2)

        if len(self.trainer_1.team) == 0 and not len(self.trainer_2.team) == 0:
            return self.trainer_2.team
        elif not len(self.trainer_1.team) == 0 and len(self.trainer_2.team) == 0:
            return self.trainer_1.team
        else:
            return None

    def optimise_battle(self) -> PokeTeam | None:
        while not len(self.trainer_1.team) == 0 and not len(self.trainer_2.team) == 0:
            p1 = self.trainer_1.team.get_first_pokemon()
            p2 = self.trainer_2.team.get_first_pokemon()

            self.trainer_1.register_pokemon(p2.value)
            self.trainer_2.register_pokemon(p1.value)

            self.battle_round(p1, p2)

        if len(self.trainer_1.team) == 0 and not len(self.trainer_2.team):
            return self.trainer_2.team
        elif not len(self.trainer_1.team) == 0 and len(self.trainer_2.team) == 0:
            return self.trainer_1.team
        else:
            return None

    def rotate_battle(self) -> PokeTeam | None:
        while not len(self.trainer_1.team) == 0 and not len(self.trainer_2.team) == 0:
            p1 = self.trainer_1.team.get_first_pokemon()
            p2 = self.trainer_2.team.get_first_pokemon()

            self.trainer_1.register_pokemon(p2)
            self.trainer_2.register_pokemon(p1)

            self.battle_round(p1, p2)

        if len(self.trainer_1.team) == 0 and not len(self.trainer_2.team) == 0:
            return self.trainer_2.team
        elif not len(self.trainer_1.team) == 0 and len(self.trainer_2.team) == 0:
            return self.trainer_1.team
        else:
            return None


if __name__ == '__main__':
    t1 = Trainer('Gary')
    t2 = Trainer('Ash')

    b = Battle(t1, t2, BattleMode.OPTIMISE)
    b._create_teams()
    t1.get_team().special(BattleMode.OPTIMISE)
    winner = b.commence_battle()
    if winner:
        print(f"Winner is not None, winner's name: {winner.get_name()}")
    else:
        print("It's a draw or there was an error determining the winner.")


