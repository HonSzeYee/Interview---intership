from data_structures.array_sorted_list import ArraySortedList
from data_structures.bset import BSet
from data_structures.queue_adt import CircularQueue
from data_structures.sorted_list_adt import ListItem
from data_structures.stack_adt import ArrayStack
from pokemon import *
from pokemon_base import *
import random
from typing import List
from battle_mode import BattleMode


class PokeTeam:
    TEAM_LIMIT = 6
    POKE_LIST = get_all_pokemon_types()
    CRITERION_LIST = ["health", "defence", "attack", "speed", "level"]

    # SHOULD NOT take any additional arguments, if take give default value
    def __init__(self, criterion="health"):
        self.team = ArrayR(self.TEAM_LIMIT)
        self.team_count = 0
        self.is_ascending_order = True
        self.criterion = criterion

    def choose_manually(self):
        all_pokemon = get_all_pokemon_types()
        index = 0
        while index < self.TEAM_LIMIT:
            for i in range(len(all_pokemon)):
                pokemon = all_pokemon[i]
                if pokemon is not None:
                    # 打印出来Pokemon的名字跟序号，让用户选
                    print(f"{i + 1}. {pokemon.__name__}")
            choice_new = input("Choose a Pokemon or Done: ")
            if choice_new.lower() == 'done':
                break
            try:
                chosen_index = int(choice_new) - 1
                if chosen_index < 0 or chosen_index >= len(all_pokemon):
                    raise ValueError
                # 直接通过索引访问ArrayR对象
                self.team[index] = all_pokemon[chosen_index]
                index += 1  # 更新索引
                self.team_count = index
            except ValueError:
                print("Invalid selection. Please try again.")

    def choose_randomly(self) -> None:
        all_pokemon = get_all_pokemon_types()
        self.team_count = 0
        for i in range(self.TEAM_LIMIT):
            rand_int = random.randint(0, len(all_pokemon) - 1)
            # self.team[i]  TypeError: 'CircularQueue' object does not support item assignment
            self.team[i] = all_pokemon[rand_int]()
            self.team_count += 1

    def regenerate_team(self, battle_mode: BattleMode, criterion: str = None) -> None:
        if battle_mode == BattleMode.SET or isinstance(self.team, ArrayStack):
            temp_stack = ArrayStack(self.TEAM_LIMIT)
            while not len(self.team) == 0:
                pokemon = self.team.pop()
                pokemon.health = pokemon.original_health
                temp_stack.push(pokemon)
            while not len(temp_stack):
                self.team.push(temp_stack.pop())

        elif battle_mode == BattleMode.ROTATE or isinstance(self.team, CircularQueue):
            for i in range(self.TEAM_LIMIT):
                pokemon = self.team.serve()
                pokemon.health = pokemon.original_health
                self.team.append(pokemon)

        elif battle_mode == BattleMode.OPTIMISE or isinstance(self.team, ArraySortedList):
            temp_array = ArraySortedList(self.TEAM_LIMIT)

            for item in self.team:
                pokemon = item.value
                pokemon.health = pokemon.original_health

                if criterion:
                    value = getattr(pokemon, criterion)()
                    temp_array.add(ListItem(pokemon, value))
                else:
                    print("No usable criterion.")

            self.team = temp_array

    def assign_team(self, criterion: str):
        if criterion not in self.CRITERION_LIST:
            raise ValueError(f"Invalid criterion.")

        # 初始化一个新的 ArraySortedList 来存储排序后的宝可梦
        sorted_team = ArraySortedList(len(self.team))
        for i in range(len(self.team)):
            pokemon = self.team[i]
            item = ListItem(pokemon, getattr(pokemon, criterion))
            sorted_team.add(item)
        self.team = ArraySortedList(len(self.team))
        for i in range(len(sorted_team)):
            self.team.add(sorted_team[i])

    def assemble_team(self, battle_mode: BattleMode, criterion: str = None) -> None:
        if battle_mode == BattleMode.SET or isinstance(self.team, ArrayStack):
            array_stack_team = ArrayStack(self.TEAM_LIMIT)
            for i in range(len(self.team)):
                pokemon = self.team[i]
                if pokemon is not None:
                    array_stack_team.push(pokemon)
            self.team = array_stack_team

        elif battle_mode == BattleMode.ROTATE or isinstance(self.team, CircularQueue):
            circular_queue = CircularQueue(self.TEAM_LIMIT)
            for i in range(len(self.team)):
                pokemon = self.team[i]  # 使用索引访问宝可梦对象
                circular_queue.append(pokemon)
            self.team = circular_queue

        elif battle_mode == BattleMode.OPTIMISE or isinstance(self.team, ArraySortedList):
            optimised_team = ArraySortedList(self.TEAM_LIMIT)

            for i in range(len(self.team)):
                pokemon = self.__getitem__(i)
                if pokemon is not None:
                    # 根据criterion获取排序键
                    if criterion:
                        sort_key = getattr(pokemon, criterion)
                    else:
                        sort_key = None

                    list_item = ListItem(pokemon, sort_key)
                    optimised_team.add(list_item)

            self.team = optimised_team

    # 运行时间过长
    def get_first_pokemon(self):
        if isinstance(self.team, ArrayStack):
            return self.team.pop()
        elif isinstance(self.team, CircularQueue):
            return self.team.serve()
        elif isinstance(self.team, ArraySortedList):
            return self.team[0]

    def special(self, battle_mode: BattleMode) -> None:
        if battle_mode == BattleMode.SET or isinstance(self.team, ArrayStack):
            # # # 算一个中心点
            median = len(self.team) // 2

            temp_queue = CircularQueue(len(self.team))
            for i in range(median):
                temp_queue.append(self.team.pop())

            for j in range(median):
                self.team.push(temp_queue.serve())

        elif battle_mode == BattleMode.ROTATE or isinstance(self.team, CircularQueue):
            # ROTATE: BOTTOM (called out last) F E D C B A FRONT (called out first) - > BOTTOM (called out last) D E F C B A FRONT (called out first)
            median = len(self.team) // 2
            temp_stack = ArrayStack(len(self.team))

            for i in range(median):
                temp_stack.push(self.team.serve())

            for j in range(median):
                self.team.append(temp_stack.pop())

        elif battle_mode == BattleMode.OPTIMISE or isinstance(self.team, ArraySortedList):
            temp_list = ArraySortedList(len(self.team))
            for i in range(len(self.team)):
                item = self.team[i]
                item.key *= -1
                temp_list.add(item)
            self.team = temp_list

    # 可能会出问题
    def remove_fainted_pokemon(self, battle_mode: BattleMode):
        self.team_count -= 1
        if battle_mode == BattleMode.SET or isinstance(self.team, ArrayStack):
            return
        elif battle_mode == BattleMode.ROTATE or isinstance(self.team, CircularQueue):
            length = len(self.team)
            for i in range(length):
                pokemon = self.team.serve()
                if pokemon.is_alive():
                    self.team.append(pokemon)
        elif battle_mode == BattleMode.OPTIMISE or isinstance(self.team, ArraySortedList):
            if len(self.team) > 0 and not self.team[0].value.is_alive():
                self.team.delete_at_index(0)

    def __len__(self):
        return self.team_count

    def __str__(self):
        return '\n'.join([self[i].__class__.__name__ for i in range(len(self.team))])

    def __getitem__(self, index: int):
        if isinstance(self.team, ArrayStack):
            pokemon = None
            temp_arraystack = ArrayStack(len(self.team))
            for i in range(len(self.team)):
                popped_item = self.team.pop()
                if i == index:
                    pokemon = popped_item
                temp_arraystack.push(popped_item)

            for i in range(len(temp_arraystack)):
                temp_item = temp_arraystack.pop()
                self.team.push(temp_item)
            return pokemon

        elif isinstance(self.team, CircularQueue):
            result = None
            for i in range(len(self.team)):
                item = self.team.serve()
                self.team.append(item)
                if i == index:
                    result = item
            return result

        elif isinstance(self.team, ArraySortedList):
            return self.team[index].value
        elif isinstance(self.team, ArrayR):
            return self.team[index]

    def send_pokemon_back(self, pokemon):
        if isinstance(self.team, ArrayStack):
            self.team.push(pokemon)
        elif isinstance(self.team, CircularQueue):
            self.team.append(pokemon)
        elif isinstance(self.team, ArraySortedList):
            pokemon = self.team.delete_at_index(0)
            if pokemon.key < 0:
                pokemon.key = -getattr(pokemon.value, self.criterion)
            else:
                pokemon.key = getattr(pokemon.value, self.criterion)
            self.team.add(pokemon)


class Trainer:

    def __init__(self, name) -> None:
        self.name = name
        self.team = PokeTeam()
        self.pokedex = BSet()

    def pick_team(self, method: str) -> None:
        if method.lower() == 'random':
            self.team.choose_randomly()
        elif method.lower() == 'manual':
            self.team.choose_manually()
        else:
            raise ValueError("Invalid method. Please choose 'Random' or 'Manual'.")

        for i in range(len(self.team)):
            pokemon = self.team[i]
            if pokemon is not None:
                self.register_pokemon(pokemon)

    def get_team(self) -> PokeTeam:
        return self.team

    def get_name(self) -> str:
        return self.name

    def register_pokemon(self, pokemon: Pokemon) -> None:
        pokedex_int = pokemon.get_poketype().value + 1
        if pokedex_int not in self.pokedex:
            return self.pokedex.add(pokedex_int)

    def get_pokedex_completion(self) -> float:
        total_pokemon_types = len(PokeType.__members__)
        unique_types_count = len(self.pokedex)
        completion_ratio = unique_types_count / total_pokemon_types if total_pokemon_types > 0 else 0
        pokedex_completion = round(completion_ratio, 2)
        return pokedex_completion

    def __str__(self) -> str:
        # completion = self.get_pokedex_completion
        completion_percentage = self.get_pokedex_completion() * 100  # No parentheses needed
        return f"Trainer {self.name} Pokedex Completion: {completion_percentage:.0f}%"


if __name__ == '__main__':
    t = Trainer('Ash')
    print("Please choose the Pokemon 'manual' or 'random'? ")
    choice = input("Please enter 'manual' or 'random': ")

    if choice == 'manual':
        t.pick_team("manual")
    elif choice == 'random':
        t.pick_team("random")
    else:
        print("Invalid choice, please try again.")

    print(t)
    print(t.get_team())
