import random

from battle_mode import BattleMode
from poke_team import Trainer, PokeTeam
from enum import Enum
from data_structures.stack_adt import ArrayStack
from data_structures.queue_adt import CircularQueue
from data_structures.array_sorted_list import ArraySortedList
from data_structures.sorted_list_adt import ListItem
from typing import Tuple
from battle import Battle

class BattleTower:
    MIN_LIVES = 1
    MAX_LIVES = 3

    def __init__(self) -> None:
        self.enemy_trainers = None
        self.enemy_teams = None
        self.player_trainer = None
        self.player_lives = 0
        self.enemy_lives = 0
        self.criterion = None
        self.enemies_defeated_count = 0

    # Hint: use random.randint() for randomisation
    def set_my_trainer(self, trainer: Trainer) -> None:
        self.player_trainer = trainer
        self.player_lives = random.randint(BattleTower.MIN_LIVES, BattleTower.MAX_LIVES)
        self.player_trainer.pick_team('random')

    def generate_enemy_trainers(self, num_teams: int) -> None:
        self.enemy_trainers = CircularQueue(num_teams)

        for i in range(num_teams):
            enemy_trainers = Trainer(f'Enemy_{i + 1}')
            enemy_lives = random.randint(BattleTower.MIN_LIVES, BattleTower.MAX_LIVES)
            enemy_trainers.pick_team('random')
            enemy_trainers.get_team().assemble_team(BattleMode.ROTATE, self.criterion)

            self.enemy_trainers.append((self.enemy_teams, enemy_lives))

    def battles_remaining(self) -> bool:
        if self.player_lives > 0 and not self.enemy_trainers.is_empty():
            # 创建一个临时队列来存储遍历过程中的元素
            temp_queue = CircularQueue(len(self.enemy_trainers))
            has_battles_remaining = False

            # 遍历队列中的所有元素
            while not self.enemy_trainers.is_empty():
                enemy_trainer, enemy_lives = self.enemy_trainers.serve()
                if enemy_lives > 0:
                    has_battles_remaining = True

                # 将元素放入临时队列
                temp_queue.append((enemy_trainer, enemy_lives))

            # 将所有元素从临时队列移回原队列
            while not temp_queue.is_empty():
                self.enemy_trainers.append(temp_queue.serve())

            return has_battles_remaining
        return False

    def next_battle(self) -> Tuple[Trainer, Trainer, Trainer, int, int]:
        enemy_trainer, lives = self.enemy_trainers.serve()
        self.player_trainer.get_team().regenerate_team(BattleMode.ROTATE)
        enemy_trainer.get_team().regenerate_team(BattleMode.ROTATE)

        lets_battle = Battle(self.player_trainer, enemy_trainer, BattleMode.ROTATE)
        winner = lets_battle.battle_round(player_trainer, enemy_trainer)

        if winner == enemy_trainer:
            self.player_lives -= 1
            self.enemy_trainers.append(enemy_trainer, self.enemy_lives)
            if lives > 0:
                self.enemy_trainers.append(enemy_trainer, self.enemy_lives)
        elif winner == player_trainer:
            self.enemies_defeated_count += 1
            self.enemy_lives -= 1
            self.player_trainer.append(player_trainer, self.player_lives)
        else:
            self.player_lives -= 1
            self.enemy_lives -= 1
            if self.enemy_lives > 0:
                return self.enemy_trainers.append(enemy_trainer, self.enemy_lives)
            if self.player_lives > 0:
                return self.player_trainer.append(player_trainer, self.player_lives)
        return self.player_trainer, self.enemy_trainers, winner, self.player_lives, self.enemy_lives


    def enemies_defeated(self) -> int:
        return self.enemies_defeated_count


if __name__ == "__main__":
    BattleTower.MIN_LIVES = 2
    BattleTower.MAX_LIVES = 10

    random.seed(20)  # rmb to delete random
    player_trainer = Trainer('Ash')
    player_trainer.pick_team("Random")
    player_trainer.get_team().assemble_team(BattleMode.ROTATE)

    bt = BattleTower()
    bt.set_my_trainer(player_trainer)
    bt.generate_enemy_trainers(2)

    BattleTower.MIN_LIVES = 2
    BattleTower.MAX_LIVES = 10
