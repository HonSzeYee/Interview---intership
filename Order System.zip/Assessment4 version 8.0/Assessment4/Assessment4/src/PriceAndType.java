/**
Author's name:HanSiYi version number:3.0
 PriceAndType is an interface, the FoodItem class implements this interface.
 PriceAndType provides implementations of the getPrice() and getMealType() methods.
 FoodItem is an abstract class and supper class of Pizza and Pasta.
 Because FoodItem is an abstract class, we need to specific achieve these two method by override them in the subclass which are Pizza and Pasta.
 */

public interface PriceAndType {

    // get the price from food or order bill
    double getPrice();

    //get the meal type from food or order bill
    FoodItem.MealType getMealType();
}
