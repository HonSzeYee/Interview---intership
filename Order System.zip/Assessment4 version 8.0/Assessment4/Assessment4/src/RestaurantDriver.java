/**
* Author's name:HanSiYi version number:3.0
 * this is the mainDrive, the main purpose to do the interaction with the user
 * and the validation part with user input
 * display the menu and interaction with user to create an order
 */


import java.util.Arrays;
import java.util.Scanner; //let use input the information
import java.util.List;
import java.util.ArrayList;

public class RestaurantDriver{
    private static OrderManager orderManager = new OrderManager();
    private static Scanner scanner = new Scanner(System.in); //let user input something

    public static void main(String[] args) {
        int choice;

        do { //do-while, at least execute one time whatever the condition is true or not
            displayMenu();
            choice = scanner.nextInt();

            if (choice == 1) {
                Order newOrder = createOrder();
                if (newOrder != null) {
                    orderManager.addOrder(newOrder); //add the newOrder to the OrderManager - addOrder
                }
            } else if (choice == 2) {
                orderManager.deliveredOrder(); //invoke OrderManager class's deliveredOrder method (public Order deliveredOrdered)

            } else if (choice == 3) {
                System.out.println(orderManager.toString());//invoke OrderManager class's toString to display the statement

            } else if (choice == 4) {
                System.out.println("Shutting Down System. Goodbye!");

            } else {
                System.out.println("Invalid choice. Please enter your choice: (1-4)");  // invalidation -  reminder the user need to input choice from 1-4

            }
        } while (choice != 4); //when the choice == 4, the code will close scanner, and exist the program

        scanner.close();
    }

    public static Order createOrder() {
        //create the order information, the information comes from user input
        Scanner scanner = new Scanner(System.in);

        String customerName;
        String deliveryAddress;
        String contactNumber;

        while (true) {  //validation - ensure the input is reasonable
            System.out.print("Enter customer name:\n");
            customerName = scanner.nextLine();

            if (customerName != null && customerName.length() > 2 && customerName.length() <= 50) {
                break;
            } else {
                System.out.println("Invalid name. Please enter a name with more than 2 and less than or equal to 50 characters.");
            }
        }

        while (true) {  //validation - ensure the input is reasonable
            System.out.print("Enter delivery address:\n");
            deliveryAddress = scanner.nextLine();
            if (deliveryAddress != null && deliveryAddress.length() > 4) {
                break;
            } else {
                System.out.println("Invalid address. Please enter an address with more than 4 characters.");
            }
        }

        while (true) {  //validation - ensure the input is reasonable
            System.out.print("Enter contact number:\n");
            contactNumber = scanner.nextLine();
            if (contactNumber != null && (contactNumber.length() == 9 || contactNumber.length() == 10)) {
                break;
            } else {
                System.out.println("Invalid contact number. Please enter a number with 9 or 10 digits.");
            }
        }

        List<FoodItem> foodItems = new ArrayList<>();

        System.out.println("\nAdding items to " + customerName + "'s order!\n");

        int choice;
        do {  //do-while, at least execute one time whatever the condition is true or not
            System.out.println("Please select an option:");
            System.out.println("==================================");
            System.out.println("1. Add a Pizza to the Order");
            System.out.println("2. Add a Pasta to the Order");
            System.out.println("3. Back to Main Menu");
            System.out.println("Please enter your choice: (1-3)");

            choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                Pizza.displayPizzaTopping(); //Because this is a static method, you can call it directly using the class name without creating an instance of the class.
                String toppingsInput = scanner.nextLine().toLowerCase();
                List<String> toppings = Arrays.asList(toppingsInput.trim().split("\\s*,\\s*"));
                // Arrays.asList - Is a static method of the Java Arrays class that takes an array and converts it to a List.


                boolean allValid = true;
                for (String t : toppings) {
                    if (!Pizza.getValidToppings().contains(t)) {
                        System.out.println("Invalid topping: " + t);
                        allValid = false;
                        break;
                    }
                }

                if (allValid) {
                    Pizza newPizza = new Pizza(toppings);
                    foodItems.add(newPizza);
                    System.out.println(newPizza + " was added to the order.\n");
                } else {
                    System.out.println("Please re-enter toppings from the given list.");
                }

            } else if (choice == 2) {
                Pasta.displayPastaTopping(); ////Because this is a static method, you can call it directly using the class name without creating an instance of the class.
                String topping = scanner.nextLine().toLowerCase();
                if (Pasta.getValidToppings().contains(topping)) {
                    Pasta newPasta = new Pasta(topping);
                    foodItems.add(newPasta);
                    System.out.println(newPasta + " was added to the order.\n");
                } else {
                    System.out.println("Please re-enter toppings from the given list.");
                }
            }


        } while (choice != 3); //if the choice not between 1 and 3, then the code will run again

        return new Order(customerName, contactNumber, deliveryAddress, foodItems);
    }

    //keyword static shows it belongs with class, not a specific instance of a class
    //static void not return anything
    public static void displayMenu() {
        String[] menuOptions = {
                "\nWelcome to the Take-Away Management Portal",
                "============================================",
                "\nPlease select an option:",
                "1. Enter Order Details",
                "2. Deliver an Order",
                "3. Display all items and customer details in the Order",
                "4. Exit",
                "Please enter your choice: (1-4)"
        };

        for (String option : menuOptions) {  //use for loop to display menu
            System.out.println(option);
        }
    }


}