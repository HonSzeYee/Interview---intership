/**
 * Author's name:HanSiYi version number:3.0
 * OrderManager manages with Order class, to show the state of the orders - delivery order - display all orders
 */

import java.util.List;
import java.util.ArrayList;

public class OrderManager {
    private List<Order> orders; //use ArrayList to store the order

    //default constructor
    public OrderManager() {
        this.orders = new ArrayList<>();
    }

    //non-default constructor
    public OrderManager(List<Order> currentOrders) {
        this.orders = new ArrayList<>(currentOrders);
    }

    //getter
    public List<Order> getOrders() {
        return orders;
    }

    //setter
    public void setOrders(List<Order> currentOrders) {
        this.orders = new ArrayList<>(currentOrders);
    }

    public String toString() {
        StringBuilder result = new StringBuilder();

        result.append("\nYou have selected to display all Orders in the System\n");
        result.append("Order Details\n");
        result.append("=====================================================\n");

        int orderNumber = 1;
        for (Order order : orders) {
            result.append("Order ").append(orderNumber).append(":\n");
            result.append(order.toString()).append("\n"); // Assuming the Order class has its own meaningful toString method.
            orderNumber++;
        }

        return result.toString();
    }

    //add the orders to the list of order
    public void addOrder(Order order) {
        orders.add(order);
    }

    //removing the oldest order from the order list
    public Order deliveredOrder() {
        if (!orders.isEmpty()) {
            Order oldestOrder = orders.remove(0);  // get and delete the oldest order
            System.out.println("\nYou have selected to deliver an order");
            System.out.println("=============================");
            System.out.println("Delivering " + oldestOrder.getCustomerName() + "'s order to " + oldestOrder.getDeliveryAddress());
            System.out.println("Order Details:");
            System.out.println(oldestOrder);
            System.out.println("There are now " + getPendingOrderCount() + " order(s) pending delivery.");
            return oldestOrder;
        } else {
            System.out.println("No orders need to deliver");
            return null;
        }
    }

    public int getPendingOrderCount() { //to show how many orders still not delivery
        return orders.size();
    }

}