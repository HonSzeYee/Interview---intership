/**
 * Author's name:HanSiYi version number:3.0
 * Pasta is a subclass, it extends FoodItem
 * getPrice() - calculate the Pasta price with/without topping - return the price to the foodPrice
 * getMealType() - return the type to FoodItem-MealType, decide what kind of the Pasta
 */
import java.util.Arrays;
import java.util.List;


public class Pasta extends FoodItem{
    //pasta: only can add single topping
    private String topping;
    private static final List<String> VALID_TOPPINGS = Arrays.asList("bolognese", "marinara", "primavera", "tomato", "no");

    //default constructor
    public Pasta() {
        super("Pasta");
        this.topping = "UNKNOWN";
        getPrice();
    }

    //non-default constructor
    public Pasta(String topping){
        super("Pasta");
        this.topping = topping.toLowerCase();
        getPrice();
    }

    //getter
    public String getTopping() {
        return topping;
    }

    public static List<String> getValidToppings() {
        return VALID_TOPPINGS;
    }

    //setter
    public void setTopping(String topping) {

        if (!VALID_TOPPINGS.contains(topping.toLowerCase())) {
            System.out.println("Invalid topping: " + topping);
            return;
        }
        this.topping = topping.toLowerCase();
        getPrice();
    }

    public String toString() {
        return "Pasta with " + topping.toUpperCase() + " (" + getMealType().toString() + ") topping(s)";
    }

    public double getPrice() {          //override the super class's getPrice method - specific implementation
        double totalAmount = BASIC_PRICE;  //use the BASIC_PRICE constant inherited from FoodItem
        switch (topping.toLowerCase()){  //use switch statement to check whether the topping's value equals with string or not
            case "tomato":               //Pasta is single topping, so we do not need for loop
                totalAmount += 4.0;
                break;
            case "bolognese":
            case "primavera":
                totalAmount += 5.20;
                break;
            case "marinara":
                totalAmount += 6.80;
                break;
        }
        this.setFoodPrice(totalAmount);
        return totalAmount;            //return the totalAmount to the FoodItem-foodPrice
    }

    public MealType getMealType(){    //override the supper class's getMealTpe method - specific implementation
        String lowercaseTopping = topping.toLowerCase(); //whatever the uppercase or lowercase, they will convert to the lowercase
        boolean hasMeat = false;
        boolean hasVegetarian = false;

        switch (lowercaseTopping) {
            case "bolognese":
            case "marinara":
                hasMeat = true;
                break;
            case "primavera":
                hasVegetarian = true;

        }
        if (hasMeat) {
            return MealType.MEAT;
        } else if (hasVegetarian) {
            return MealType.VEGETARIAN;
        } else {
            return MealType.VEGAN;
        }
    }


    public static void displayPastaTopping(){
        System.out.println("\nTopping Options (single topping):");
        for (String topping : VALID_TOPPINGS) {
            System.out.println(topping.toUpperCase());
        }
        System.out.println("\nEnter the topping you want (choose only one or enter no for no toppings): ");
    }
}
