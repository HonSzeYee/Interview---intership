/**
 * Author's name:HanSiYi version number:3.0
 * Pizza is a subclass, it extends FoodItem
 * specific implementation - getPrice, getMealType in Pizza
 */

import java.util.List; //List is an interface in Java
import java.util.ArrayList; //ArrayList is an implementation class of the List interface
import java.util.Arrays;

public class Pizza extends FoodItem{

    //the list to store the pizza toppings, because we can choose more than one topping
    private List<String> topping;
    private static final List<String> VALID_TOPPINGS = Arrays.asList("ham", "cheese", "pineapple", "mushrooms", "tomato", "seafood", "no");
    //Arrays.asList has difference with ArrayList, Arrays.asList is a static method of ArrayList
    //it returns a fix size list and can not add or delete element
    //has a knew,fixed size element, it is better to use Arrays.asList

    //default constructor
    public Pizza() {
        super("Pizza");
        this.topping = new ArrayList<>(); //create a new empty ArrayList object and assign it to the topping member variable
        getPrice();
    }

    //non-default constructor
    public Pizza(List<String> toppings){
        super("Pizza");
        this.topping = toppings;
        getPrice();
    }

    //getter
    public List<String> getToppings() {
        return topping;
    }

    public static List<String> getValidToppings() {
        return VALID_TOPPINGS;
    }

    //setter with validation
    public void setToppings(List<String> toppings) {
        for (String t : toppings) {
            if (!VALID_TOPPINGS.contains(t.toLowerCase())) {
                System.out.println("Invalid topping: " + t);
                return;  //  ask user for re-entry the topping
            }
        }
        this.topping = toppings;
        getPrice();
    }

    public String toString() {
        return "Pizza with " + String.join(", ", topping).toUpperCase() + " (Contains " + getMealType().toString() + ") topping(s)";
    }

    //override the super class's getPrice method - specific implementation
    public double getPrice() {
        double totalAmount = BASIC_PRICE; // use the BASIC_PRICE constant inherited from FoodItem
        for (String elem : topping) {
            String toppingLower = elem.toLowerCase(); ////use switch statement to check whether the topping's value equals with string or not
            switch (toppingLower) {
                case "ham":
                case "cheese":
                case "mushrooms":
                case "tomato":
                    totalAmount += 2.0;
                    break;
                case "pineapple":
                    totalAmount += 2.50;
                    break;
                case "seafood":
                    totalAmount += 3.50;
                    break;
            }
        }
        this.setFoodPrice(totalAmount);
        return totalAmount;
    }

    //override the supper class's getMealTpe method - specific implementation
    public MealType getMealType() {
        boolean hasMeat = false;
        boolean hasVegetarian = false;

        for (String t : topping) {
            String lowercaseTopping = t.toLowerCase();
            switch (lowercaseTopping) {
                case "ham":
                case "seafood":
                    hasMeat = true;
                    break;
                case "cheese":
                    hasVegetarian = true;
                    break;
            }
        }

        if (hasMeat) {
            return MealType.MEAT;
        } else if (hasVegetarian) {
            return MealType.VEGETARIAN;
        } else {
            return MealType.VEGAN;
        }
    }

    public static void displayPizzaTopping() {
        System.out.println("\nTopping Options:");
        for (String topping : VALID_TOPPINGS) {
            System.out.println(topping.toUpperCase());
        }
        System.out.println("\nEnter toppings you want separated by a comma (you can choose more than one or enter no for no toppings: ");
    }

}
