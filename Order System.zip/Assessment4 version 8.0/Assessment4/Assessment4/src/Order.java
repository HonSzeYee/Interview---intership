/**
 * Author's name:HanSiYi version number:3.0
 * Order class focus on deal with customer information, also show the order info
 * This class provides functionalities to calculate the total payment, determine the meal type,
 */

import java.util.List;
import java.util.ArrayList;

public class Order {
    private final String deliveryAddress; //final - once assign, cannot change
    private List<FoodItem> foodItems;
    private final String customerName;
    private final String contactNumber;
    private String mealType;
    private double totalPayment;

    //default constructor
    public Order() {
        this.customerName = "";
        this.contactNumber = "";
        this.deliveryAddress = "";
        this.foodItems = new ArrayList<>(); //foodItems are declared as a List, but their actual object is an ArrayList
        this.totalPayment = 0;
        this.mealType = "UNKNOWN";
    }

    //non-default constructor
    public Order(String customerName, String contactNumber, String deliveryAddress, List<FoodItem> foodItems){
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.deliveryAddress = deliveryAddress;
        this.foodItems = foodItems;
        TotalPayment();
        determineMealType();
    }

    public String getCustomerName(){
        return customerName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getDeliveryAddress(){
        return deliveryAddress;
    }

    public double getTotalPayment(){
        return totalPayment;
    }

    public List<FoodItem> getFoodItems() {
        return foodItems;
    }

    public String getMealType() {
        return mealType;
    }


    public void setFoodItems(List<FoodItem> foodItems) {
        this.foodItems = foodItems;
        TotalPayment();
        determineMealType();
    }

    public void setTotalPayment(double totalPayment){
        this.totalPayment = totalPayment;
    }

    public void setMealType(String mealType){
        this.mealType = mealType;
    }

    public String toString() {
        StringBuilder ol = new StringBuilder();
        ol.append("Customer Info:\n");
        ol.append("-----------------\n");
        ol.append("    Customer Name: ").append(getCustomerName()).append("\n");
        ol.append("    Customer Address: ").append(getDeliveryAddress()).append("\n");
        ol.append("    Customer Phone: ").append(getContactNumber()).append("\n");
        ol.append("Items in the order:\n");
        ol.append("---------------------\n");
        for (FoodItem item : foodItems) {
            ol.append("    ").append(item.toString()).append("-------> Price: $").append(item.getPrice()).append("\n");
        }
        ol.append("Order Info:\n");
        ol.append("----------------\n");
        ol.append("    Total Order Price: $").append(getTotalPayment()).append("\n");
        ol.append("    Order Meal Type: Contains ").append(getMealType());
        return ol.toString();
    }

    public void TotalPayment(){
        totalPayment = 0;
        for (FoodItem elem : foodItems){ //each food item in the order and accumulate its price
            totalPayment += elem.getFoodPrice();
        }
    }

    public void determineMealType(){
        boolean containsMeat = false;
        boolean containsVegetarian = false;

        //for loop, through each food item in the order to determine its type
        for (FoodItem elem : foodItems) {
            String type = String.valueOf(elem.getMealType());
            if ("MEAT".equals(type)) {
                containsMeat = true;
            } else if ("VEGETARIAN".equals(type)) {
                containsVegetarian = true;
            }
        }

        //decide the meal type for the entire order based on the items what it contains
        if (containsMeat) {
            mealType = "MEAT";
        } else if (containsVegetarian) {
            mealType = "VEGETARIAN";
        } else {
            mealType = "VEGAN";
        }
    }

}
