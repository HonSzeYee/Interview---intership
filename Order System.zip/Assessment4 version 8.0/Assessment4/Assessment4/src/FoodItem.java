/**
 * Author's name:HanSiYi version number:3.0
 * Design FoodItem as an abstract class which is supper class, and the Pizza, Pasta as the subclasses.
 * supper class define the common attributes and method with subclasses
 * two subclasses have foodName and foodPrice & getPrice and getMealType
 * subclasses' getPrice has a different calculate method and getMealType logic with supper class, so we override getPrice, getMealType method in their own class
 */

public abstract class FoodItem implements PriceAndType{

    //enum as constant the variable name should use uppercase
    //enum presents a set of named constant. we cannot re-assign the value to the constant(the value of constant already be defined in the enum)(safety)
    public enum MealType{
        MEAT, VEGETARIAN, VEGAN
    }

    //defining the food name and food price
    private String foodName;
    private double foodPrice;

    //because the pizza and pasta have the same base price which is 11.50
    //use keyword final to define the constant.
    //constant should use uppercase
    protected static final double BASIC_PRICE = 11.50;

    public FoodItem(){
        this.foodName = "";
        this.foodPrice = 0.0;
    }

    public FoodItem(String foodName){
        this.foodName = foodName;
        this.foodPrice = BASIC_PRICE;
    }

    //setter
    public void setFoodName(String foodName){
        this.foodName = foodName;
    }

    //setter
    public void setFoodPrice(double foodPrice){
        this.foodPrice = foodPrice;
    }

    //getter
    public String getFoodName(){
        return foodName;
    }

    //getter
    //methods to implement the PriceAndType interface
    public double getFoodPrice(){
        return foodPrice;
    }

    //an abstract method is a method that is declared in a supper class (or interface) but not implemented, we can specific implement them in the subclasses.
    //subclasses are responsible for providing the concrete implementation.
    public abstract MealType getMealType();
    public abstract double getPrice();

    //we override toString method in the subclasses (Pizza, Pasta)
    public String toString(){
        String ret = "";
        ret += "Food name: " + getFoodName();
        ret += "Food price: " + getFoodPrice();
        ret += "Food type" + getMealType();
        return ret;
    }
}
